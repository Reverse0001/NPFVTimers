﻿using Microsoft.EntityFrameworkCore;
using Rapp.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rapp.Services
{

    public static class CompiledQueries
    {
        public static readonly Func<DbService, IAsyncEnumerable<Invistering>> GetInvisteringerAsync = 
            EF.CompileAsyncQuery((DbService context) => 
            context.Invisteringer);

        public static readonly Func<DbService, string, Task<Invistering>> GetSingleInvesteringAsync =
         EF.CompileAsyncQuery((DbService context, string investeringName) =>
             context.Invisteringer.FirstOrDefault(i => i.Name == investeringName)
                 );

        public static readonly Func<DbService, IAsyncEnumerable<BpKit>> GetBpKitsAsync =
          EF.CompileAsyncQuery((DbService context) =>
          context.BpKits.AsNoTracking());

        public static readonly Func<DbService, IAsyncEnumerable<KitNeverExpire>> GetKitsAsync =
            EF.CompileAsyncQuery((DbService context) =>
            context.kitNeverExpires.AsNoTracking());

        public static readonly Func<DbService, int, Task<KitNeverExpire>> GetNEKitAsyncViaId =
            EF.CompileAsyncQuery((DbService context, int id) =>
                context.kitNeverExpires.FirstOrDefault(i => i.Id == id));

        public static readonly Func<DbService, int, Task<BpKit>> GetBpKitAsyncViaId =
            EF.CompileAsyncQuery((DbService context, int id) =>
                context.BpKits.FirstOrDefault(i=>i.Id == id));


        public static readonly Func<DbService,int,Task<Grund>> GetSingleGrundViaIdAsync =
            EF.CompileAsyncQuery((DbService context, int id) =>
                context.Grunde.AsNoTracking().FirstOrDefault(g=>g.Id == id));

        public static readonly Func<DbService, string, Task<Grund>> GetSingleGrundAsync =
            EF.CompileAsyncQuery((DbService context, string grundName) =>
                context.Grunde.AsNoTracking().FirstOrDefault(g=>g.Name == grundName)
                    );

        public static readonly Func<DbService, IAsyncEnumerable<Grund>> GetGrundeAsync =
          EF.CompileAsyncQuery((DbService context) =>
          context.Grunde.AsNoTracking());

    }
                                                                                //Use select to only take properties that are needed Iqueryable 
    public class AsyncDbTasks
    {
        public async IAsyncEnumerable<Grund> GetGrundeAsync()
        {
            using (var context = new DbService())
            {
                //var grunde = await CompiledQueries.GetGrundeAsync(context).AsAsyncEnumerable().ConfigureAwait(false);
                await foreach(var item in CompiledQueries.GetGrundeAsync(context).ConfigureAwait(false)) 
                {
                    yield return item;
                }
            }
        }

        public async IAsyncEnumerable<Invistering> GetInvisteringerAsync()
        {
            using (var context = new DbService())
            {
                await foreach(var item in CompiledQueries.GetInvisteringerAsync(context))
                {
                    yield return item;
                }
            }
        }

        public async IAsyncEnumerable<BpKit> GetBpKitsAsync()
        {
            using (var context = new DbService())
            {
                await foreach (var item in CompiledQueries.GetBpKitsAsync(context))
                {
                    yield return item;
                }
            }
        }

        public async IAsyncEnumerable<KitNeverExpire> GetKitsAsync()
        {
            using(var context = new DbService())
            {
                await foreach(var item in CompiledQueries.GetKitsAsync(context))
                {
                    yield return item;
                }
            }
        }

        public async Task<Grund> GetSingleGrundAsync(string grundNavn)
        {
            using (var context = new DbService())
            {
                return await CompiledQueries.GetSingleGrundAsync(context, grundNavn).ConfigureAwait(false);
            }
        }

        public async Task<Invistering> GetSingleInvesteringAsync(string investeringName)
        {
            using(var context = new DbService())
            {
                return await CompiledQueries.GetSingleInvesteringAsync(context, investeringName);
            }
        }

        public async Task<KitNeverExpire> SaveNEKitAsync(KitNeverExpire kitNeverExpire)
        {
            using (var context = new DbService())
            {
                var fetchKitFormDb = await CompiledQueries.GetNEKitAsyncViaId(context,kitNeverExpire.Id);
                if(fetchKitFormDb.Name =="Key")
                {
                    fetchKitFormDb.LastTaken = DateTime.Now;
                    fetchKitFormDb.CanBeTaken = DateTime.Now.AddDays(4);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                else
                {
                    fetchKitFormDb.LastTaken = DateTime.Now;
                    fetchKitFormDb.CanBeTaken = DateTime.Now.AddDays(1);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                return null;
            }
        }

        public async Task<BpKit> SaveBpKitAsync(BpKit bpKit)
        {
            using (var context = new DbService())
            {
                var fetchKitFromDb = await CompiledQueries.GetBpKitAsyncViaId(context,bpKit.Id).ConfigureAwait(false);
                fetchKitFromDb.LastTaken = DateTime.Now;
                await context.SaveChangesAsync().ConfigureAwait(false);
                return null;
            }
        }
        public async Task<Grund> SaveGrundAsync(DateTime newDate,Grund grundToUpdate)
        {
            using (var context = new DbService())
            {
                var FetchGrundFromDb = await CompiledQueries.GetSingleGrundViaIdAsync(context, grundToUpdate.Id).ConfigureAwait(false);
                FetchGrundFromDb.LastTimeDaysWereAddedDate = newDate;
                await context.SaveChangesAsync().ConfigureAwait(false);
                return null;
            }
        }

        public async Task<Invistering> SaveInvisteringAsync(Invistering invisteringToUpdate)
        {
            using (var context = new DbService())
            {
                var fetchInvisteringFromDb = await context.Invisteringer.FirstOrDefaultAsync(i=>i.Id == invisteringToUpdate.Id).ConfigureAwait(false);
                fetchInvisteringFromDb.LastTakenDate = DateTime.Now;
                await context.SaveChangesAsync().ConfigureAwait(false);
                return null;
            }
        }
    }
}
