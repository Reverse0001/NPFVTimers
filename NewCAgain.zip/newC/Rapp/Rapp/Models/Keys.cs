﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rapp.Models
{
    public class Keys
    {
        public int Id { get; set; }
        public DateTime LastTaken { get; set; }
        public string Name { get; set; }
    }
}
