﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Tokens;
using Rapp.Models;
using Rapp.Services;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Xml;


// Lol læs koden på eget ansvar. Sgu da ikke fordi jeg magter ryde det op.
// disclaimer:) Nu er du advaret


//  TODO 
// Clean up your shit. Spelling and varible names. Use english for everything exebt wahts being displayed to the user. optimize. 
// hvis en grund eller invistering er loobet ud. skal den skifte til rood med farve. bp kits skal bare forsvinde  
// add invalid input warning for kits during create kit option 

// add set specefik cooldown for kits 
// add go back oftion. but defult will be throw error for invalid input 

// rename and clean Dbservice 
// clean progma file 
// add exception handling in asyncDbTasks
// error d for done but number convertion later
// 

// Ugyldige inputs?? Null, wrong type aka strng when i want number and vise virsa. white spce. specialc kacaters 

// logging inside the asyncDbTass.cs 


// remove kit. throw error at incorrect catogory selected. validate 
#region OnInit
var userInput = 0;
var asyncDbTasks = new AsyncDbTasks();

AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
TaskScheduler.UnobservedTaskException += TaskScheduler_UnobservedTaskException;

#endregion

while (true)
{
    await DisplayMainMenu().ConfigureAwait(false);
    int.TryParse(Console.ReadLine(), out userInput);

    if (userInput == 1)    
    {
        await DisplayGrundeMenu().ConfigureAwait(false);
    }
    else if (userInput == 2)
    {
        await DisplayInvisteringer().ConfigureAwait(false);  
    }
    else if (userInput == 3)
    {
        await DisplayKits().ConfigureAwait(false);
    }
    Console.Clear();
}


async Task DisplayMainMenu()
{
    Console.WriteLine("FV Dashboard");
    Console.WriteLine("\n");
    Console.WriteLine("--- Options ---");
    Console.WriteLine("1. Grunde.");
    Console.WriteLine("2. Investeringer.");
    Console.WriteLine("3. Kits.");
    Console.Write("--> ");
}

async Task DisplayGrundeMenu()
{
    try
    {
        using (var context = new DbService())
        {
            #region DisplayGrundeMenuOnInit
            Console.Clear();
        grundeLabel:;
            var grunde = asyncDbTasks.GetGrundeAsync().ConfigureAwait(false);
            Console.WriteLine("     --- Dine Grunde ---");
            #endregion

            #region DisplayGrundTemplate
            await foreach (var grund in grunde)
            {
                var dagee2 = grund.LastTimeDaysWereAddedDate + TimeSpan.FromDays(9);
                var tilbage = (dagee2 - DateTime.Now).TotalDays;
                Console.WriteLine("---------------------------------");
                Console.WriteLine($"Navn: {grund.Name}.");
                Console.WriteLine($"Udløber den: {dagee2}(Tidligst)");
                Console.WriteLine($"Udløber om: {tilbage}, dage(Tidligst)");
                if (tilbage <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart. Add dage."); goto skipState; }
                if (tilbage <= 7) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Kunne være du skulle overveje at adde dage"); goto skipState; }
                if (tilbage <= 10) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer for at den udløber"); goto skipState; }
            skipState:;
                Console.ForegroundColor = ConsoleColor.White;
            }
            #endregion

            #region GrundeOptions
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("--- Options ---");
            Console.WriteLine("1. Add Grund");
            Console.WriteLine("2. Del Grund");
            Console.WriteLine("3. AddDays Grund");
            Console.WriteLine("X/Enter. Gå tilbage");
            Console.Write("--> ");
            var userInput2 = 0;
            int.TryParse(Console.ReadLine(), out userInput2);
            #endregion

            if (userInput2 == 1)
            {
                #region GrundOptionAddGrund
            tryagain:;
                Console.WriteLine("Fortryd?: f");
                Console.Write("Grund Navn --> ");
                var grundNavn = Console.ReadLine();
                if (grundNavn == "f") { Console.Clear(); goto grundeLabel; }
                else
                {
                    if (String.IsNullOrWhiteSpace(grundNavn)) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("Din grund skal have et navn"); Console.ForegroundColor = ConsoleColor.White; goto tryagain; }
                    await foreach (var grund in grunde)
                    {
                        if (grund.Name == grundNavn) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("Dine grunde skal have unikke navne"); Console.ForegroundColor = ConsoleColor.White; goto tryagain; }
                    }
                    var grundSomAddes = new Grund()
                    {
                        Name = grundNavn,
                        LastTimeDaysWereAddedDate = DateTime.Now,
                    };

                    await context.Grunde.AddAsync(grundSomAddes).ConfigureAwait(false);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                    Console.Clear();
                    goto grundeLabel;
                }
                #endregion
            }

            if (userInput2 == 2)
            {
                #region GrundOptionRemoveGrund

            delgrundretry:;
                bool wasDeleted = false;
                Console.WriteLine("Fortryd?: f");
                Console.Write("Slet grund med navnet --> ");
                var grundToDelete = Console.ReadLine();
                if (grundToDelete == "f") { Console.Clear(); goto grundeLabel; }
                else
                {
                    if (String.IsNullOrWhiteSpace(grundToDelete)) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("Invalid grund navn"); Console.ForegroundColor = ConsoleColor.White; goto delgrundretry; }
                    await foreach (var grund in grunde)
                    {
                        if (grund.Name == grundToDelete)
                        {
                            context.Remove(grund);
                            wasDeleted = true;
                        }
                    }
                    await context.SaveChangesAsync().ConfigureAwait(false);
                    if (wasDeleted == false) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine($"Kunne ikke finde en grund med navnet {grundToDelete}"); Console.ForegroundColor = ConsoleColor.White; goto delgrundretry; }
                    Console.Clear();
                    goto grundeLabel;

                }
                #endregion
            }

            if (userInput2 == 3)
            {
                #region GrundOptionAddDays
            retryyy:;
                Console.WriteLine("Fortryd?: f");
                Console.Write("Hvilken grund(navn)? --> ");
                var grundNavn = Console.ReadLine();
                if (grundNavn == "f")
                {
                    Console.Clear();
                    goto grundeLabel;
                }
                else
                {
                    if (String.IsNullOrWhiteSpace(grundNavn)) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("Invalid grund navn"); Console.ForegroundColor = ConsoleColor.White; goto retryyy; }
                    var grundDerSkalOpdateres = await asyncDbTasks.GetSingleGrundAsync(grundNavn).ConfigureAwait(false);
                    if (grundDerSkalOpdateres == null) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine($"Kunne ikke finde en grund med navnet {grundNavn}"); Console.ForegroundColor = ConsoleColor.White; goto retryyy; }
                    Console.WriteLine("1. Add max dage");
                    Console.WriteLine("2. Set specifik tid");
                    Console.WriteLine("9. Fortryd");
                retry:;
                    Console.Write("--> ");
                    var userInput3 = 0;
                    int.TryParse(Console.ReadLine(), out userInput3);

                    if (userInput3 != 1 && userInput3 != 2 && userInput3 != 9)
                    {
                        await ThrowErrorAsyncInline($"Invalid input: {userInput3}").ConfigureAwait(false);
                        goto retry;
                    }
                    if (userInput3 == 9)
                    {
                        Console.Clear();
                        goto grundeLabel;
                    }
                    if (userInput3 == 1)
                    {
                        await asyncDbTasks.SaveGrundAsync(DateTime.Now, grundDerSkalOpdateres).ConfigureAwait(false);
                    }
                    else if (userInput3 == 2)
                    {
                        var setDays = 9;
                        Console.Write("Sæt dage til --> ");
                        int.TryParse(Console.ReadLine(), out setDays);  
                        if (setDays == 0) { await ThrowErrorAsyncInline($"Ugyldigt input: {setDays}").ConfigureAwait(false); Thread.Sleep(1000); goto grundeLabel; }
                      
                        await asyncDbTasks.SetExpireDateManuallyAsync(grundDerSkalOpdateres.Name, setDays).ConfigureAwait(false);

                    }
                    Console.Clear();
                    goto grundeLabel;
                }
                #endregion
            }
        }
    }
    catch (Exception ex)
    {
        LogError(ex);
        Console.WriteLine("An error occurred while displaying grunde menu. Please contect the dev.");
        Console.ReadLine();
    }
}

async Task DisplayInvisteringer()
{
    try
    {
        using (var context = new DbService())
        {
            #region DisplayInvisteringerOnInit 
        InvisteringerMainMenn:;
            Console.Clear();
            var invisteringer = asyncDbTasks.GetInvisteringerAsync();
            Console.WriteLine("--- Invisteringer ---");
            var activeInvestments = new List<string>();
            #endregion

            #region DisplayInvisteringerTemplate 
            await foreach (var item in invisteringer)
            {
                DateTime Udlllob = item.LastTakenDate.AddDays(10);
                DateTime targetTime = item.LastTakenDate.AddHours(24);
                TimeSpan kanTagesOm = targetTime - DateTime.Now;
                var udlooberOm = (Udlllob - DateTime.Now).TotalDays;
                activeInvestments.Add(item.Name);
                if (targetTime < DateTime.Now)
                {
                    Console.WriteLine("---------------------------------");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Invisterings navn: {item.Name}");
                    Console.WriteLine($"Denne invistering er klar!:D");
                    Console.WriteLine($"Udløber om: {udlooberOm}, Dage");
                    Console.WriteLine($"Udløber den: {item.LastTakenDate.AddDays(10)}");
                    if (udlooberOm <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart"); goto skipState; }
                    if (udlooberOm <= 7) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Burde måske tage den snart"); goto skipState; }
                    if (udlooberOm <= 11) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer"); goto skipState; }
                skipState:;
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {

                    Console.WriteLine("---------------------------------");
                    Console.WriteLine($"Invisterings navn: {item.Name}");
                    Console.WriteLine($"Kan tages om: {kanTagesOm}, Timer/Min/Sek");
                    Console.WriteLine($"Udløber om: {udlooberOm}, Dage");
                    Console.WriteLine($"Udløber den: {item.LastTakenDate.AddDays(10)}");
                    if (udlooberOm <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart"); goto skipState; }
                    if (udlooberOm <= 7) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Burde måske tage den snart"); goto skipState; }
                    if (udlooberOm <= 11) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer"); goto skipState; }
                skipState:;
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            #endregion

            #region InvisteringerOptinos 
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("--- Options ---");
            Console.WriteLine("1. Opret Invistering");
            Console.WriteLine("2. Slet Invisterings");
            Console.WriteLine("3. Tag Invistering");
            Console.WriteLine("4. Sæt Invisterings timer manuelt");
            Console.WriteLine("x/Enter. Gå tilbage");
            Console.Write("--> ");
            var userInput5 = 0;
            int.TryParse(Console.ReadLine(), out userInput5);
            #endregion

            if (userInput5 == 1)
            {
                #region InvisteringOptionAddInvistering
                Console.WriteLine("\n");
                Console.WriteLine(("--- Invisteringer du kan adde ---"));

                if (activeInvestments.Contains("Lego tower"))
                {
                    await ThrowErrorAsyncInline("1. Lego tower(Den har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("1. Lego tower");
                }

                if (activeInvestments.Contains("V tower"))
                {
                    await ThrowErrorAsyncInline("2. V tower(Den har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("2. V tower");
                }

                if (activeInvestments.Contains("The diner"))
                {
                    await ThrowErrorAsyncInline("3. The diner(Den har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("3. The diner");
                }

                if (activeInvestments.Contains("Zazbar"))
                {
                    await ThrowErrorAsyncInline("4. Zazbar(Den har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("4. Zazbar");
                }

                if (activeInvestments.Contains("Xpark"))
                {
                    await ThrowErrorAsyncInline("5. Xpark(Den har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("5. Xpark");
                }

                if (activeInvestments.Contains("XenoCorp"))
                {
                    await ThrowErrorAsyncInline("6. XenoCorp(Den har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("6. XenoCorp");
                }


                if (activeInvestments.Contains("AFK industries"))
                {
                    await ThrowErrorAsyncInline("7. AFK industries(Den har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("7. AFK industries");
                }

                if (activeInvestments.Contains("DiaMinen"))
                {
                    await ThrowErrorAsyncInline("8. DiaMinen(Den har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("8. DiaMinen");
                }


                Console.WriteLine("x/Enter. Gå tilbage");

            InvisteringAddretry:;
                Console.Write("--> ");
                var userInput8 = 0;
                int.TryParse(Console.ReadLine(), out userInput8);
                bool wasAdded = false;
                switch (userInput8)
                {
                    case 1:
                        #region AddLegoTower
                        if (activeInvestments.Contains("Lego tower"))
                        {
                            Console.WriteLine("\n");
                            await ThrowErrorAsyncInline("Du har allerade den invistering").ConfigureAwait(false);
                            goto InvisteringAddretry;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "Lego tower",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 2:
                        #region AddVTower
                        if (activeInvestments.Contains("V tower"))
                        {
                            Console.WriteLine("\n");
                            await ThrowErrorAsyncInline("Du har allerade den invistering").ConfigureAwait(false);
                            goto InvisteringAddretry;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "V tower",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 3:
                        #region AddTheDiner
                        if (activeInvestments.Contains("The diner"))
                        {
                            Console.WriteLine("\n");
                            await ThrowErrorAsyncInline("Du har allerade den invistering").ConfigureAwait(false);
                            goto InvisteringAddretry;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "The diner",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 4:
                        #region AddZazbar
                        if (activeInvestments.Contains("Zazbar"))
                        {
                            Console.WriteLine("\n");
                            await ThrowErrorAsyncInline("Du har allerade den invistering").ConfigureAwait(false);
                            goto InvisteringAddretry;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "Zazbar",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 5:
                        #region AddXpark
                        if (activeInvestments.Contains("Xpark"))
                        {
                            Console.WriteLine("\n");
                            await ThrowErrorAsyncInline("Du har allerade den invistering").ConfigureAwait(false);
                            goto InvisteringAddretry;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "Xpark",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 6:
                        #region AddXenoCorp
                        if (activeInvestments.Contains("XenoCorp"))
                        {
                            Console.WriteLine("\n");
                            await ThrowErrorAsyncInline("Du har allerade den invistering").ConfigureAwait(false);
                            goto InvisteringAddretry;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "XenoCorp",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 7:
                        #region AddAFKindustries
                        if (activeInvestments.Contains("AFKindustries"))
                        {
                            Console.WriteLine("\n");
                            await ThrowErrorAsyncInline("Du har allerade den invistering").ConfigureAwait(false);
                            goto InvisteringAddretry;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "AFKindustries",
                                LastTakenDate = DateTime.Now,
                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 8:
                        #region AddDiaMinen
                        if (activeInvestments.Contains("DiaMinen"))
                        {
                            Console.WriteLine("\n");
                            await ThrowErrorAsyncInline("Du har allerade den invistering").ConfigureAwait(false);
                            goto InvisteringAddretry;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "DiaMinen",
                                LastTakenDate = DateTime.Now,
                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                        #endregion

                }
                if (wasAdded)
                {
                    wasAdded = false;
                }
                else
                {
                    await ThrowErrorAsyncInline($"Ugyldigt input: {userInput8}");
                    Thread.Sleep(1000);
                }
                goto InvisteringerMainMenn;



                #endregion
            }

            if (userInput5 == 2)
            {
                #region InvisteringOptionRemoveInvistering
                Console.WriteLine("\n");
                Console.WriteLine("--- Invisteringer du skal slette ---");
                await foreach (var item in invisteringer)
                {
                    Console.WriteLine(item.Id + ". " + item.Name);
                }
                Console.WriteLine("\n");
                Console.Write("Slet invistering med nummer --> ");
                var userInput9 = 0;
                int.TryParse(Console.ReadLine(), out userInput9);
                bool wasSaved = false;
                await foreach (var item in invisteringer)
                {
                    if (item.Id == userInput9) { context.Remove(item); wasSaved = true; }
                }
                if (wasSaved)
                {
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                else
                {
                    await ThrowErrorAsyncInline($"Kunne ikke finde en invistering med id: {userInput9}");
                    Thread.Sleep(1000);
                }
                wasSaved = false;
                goto InvisteringerMainMenn;
                #endregion
            }

            if (userInput5 == 3)
            {
                #region InvisteringOptionTakeInvistering
                Console.WriteLine("\n");
                Console.WriteLine("--- Inviteringer ---");
                await foreach (var item in invisteringer)
                {
                    Console.WriteLine($"{item.Id}. {item.Name}");
                }
                Console.WriteLine("\n");
            Repeat:;
                Console.WriteLine("f. Færdig");
                Console.Write("Inviterings nummer --> ");
                var userInput6 = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(userInput6)) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("ERROR. Invalid ID. Try again."); Console.ForegroundColor = ConsoleColor.White; goto Repeat; }
                if (userInput6 == "f") { Console.Clear(); goto InvisteringerMainMenn; } // DONE  
                else
                {
                    if (!int.TryParse(userInput6, out int userInputToInt))
                    {
                        Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("ERROR. Invalid ID. Try again."); Console.ForegroundColor = ConsoleColor.White; goto Repeat;
                    }
                    bool wasSaved = false;

                    await foreach (var item in invisteringer)
                    {
                        if (item.Id == userInputToInt)
                        {
                            await asyncDbTasks.SaveInvisteringAsync(item).ConfigureAwait(false);
                            wasSaved = true;
                            Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("Invistering blev opdateret:)"); Console.ForegroundColor = ConsoleColor.White;
                        }
                    }

                    if (!wasSaved)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($" ERR! - Kunne ikke finde et kit med id {userInput6}");
                        Console.ForegroundColor = ConsoleColor.White;
                        Thread.Sleep(1000);
                    }
                    wasSaved = false;

                    goto Repeat;
                }

                #endregion
            }

            if (userInput5 == 4)
            {
                #region InvisteringOptionSetspecificTimer
                await foreach (var item in invisteringer)
                {
                    Console.WriteLine($"{item.Id}. {item.Name}");
                }
                Console.WriteLine("\n");
                Console.Write("hvilken invistering skal ændres(id) --> ");
                var invisteringId = 0;
                int.TryParse(Console.ReadLine(), out invisteringId);  // validate 
                if(invisteringId == 0) { await ThrowErrorAsyncInline($"Ugyldigt input: {invisteringId}").ConfigureAwait(false); Thread.Sleep(1000); goto InvisteringerMainMenn; }
              
                Console.Write("Hvor mange dage er det tilbage lige nu? --> ");
                var invisterDage = 0;
                int.TryParse(Console.ReadLine(), out invisterDage);  // validate 
                if (invisterDage == 0) { await ThrowErrorAsyncInline($"Ugyldigt input: {invisterDage}").ConfigureAwait(false); Thread.Sleep(1000); goto InvisteringerMainMenn; }

                await asyncDbTasks.SetExpireDatemanuallyInvistAsync(invisteringId, invisterDage).ConfigureAwait(false);
                

                goto InvisteringerMainMenn;
                #endregion
            }
        }
    }
    catch(Exception ex)
    {
        LogError(ex);
        Console.WriteLine("An error occurred while displaying invistering menu. Please contect the dev.");
        Console.ReadLine();
    }
     
}

async Task DisplayKits()
{
    try
    {
        using (var context = new DbService())
        {
            #region DisplayKitsOnInit
        displayKitsMenu:;
            Console.Clear();
            var activeKits = new List<string>();
            var activeKitsBp = new List<string>();
            var bpKits = asyncDbTasks.GetBpKitsAsync().ConfigureAwait(false);
            var kitsDontExpire = asyncDbTasks.GetKitsAsync().ConfigureAwait(false);
            Console.WriteLine("-------- Kits -----------");
            #endregion

            #region DisplayKitsTemplate
            await foreach (var kit in kitsDontExpire)
            {
                if (kit.CanBeTaken < DateTime.Now)
                {
                    Console.WriteLine("---------------------------------");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Kit: Kit {kit.Name}.");
                    Console.WriteLine($" Dette kit er klar!:D");
                    activeKits.Add(kit.Name);
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.WriteLine("---------------------------------");
                    Console.Write($"Kit: Kit {kit.Name}");
                    Console.WriteLine($" Kan tages om {kit.CanBeTaken - DateTime.Now}");
                    activeKits.Add(kit.Name);
                }
            }

            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("-------- Bp Kits -----------");
            Console.WriteLine("Slettes automatisk når de udløber ( jear måske XD. Jeg satser/håber )");
            await foreach (var kit in bpKits)
            {

                var targetTime = kit.LastTaken.AddDays(1);
                var canBeTakenHours = targetTime - DateTime.Now;
                if (kit.ExpireDate < DateTime.Now) { context.BpKits.Remove(kit); await context.SaveChangesAsync().ConfigureAwait(false); }

                else if (targetTime < DateTime.Now)
                {
                    Console.WriteLine("---------------------------------");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Kit: {kit.Name}.");
                    Console.WriteLine($" Dette kit er klar!:D");
                    Console.WriteLine($"Udløber den: {kit.ExpireDate}");
                    activeKitsBp.Add(kit.Name);
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.WriteLine("---------------------------------");
                    Console.Write($"Kit: {kit.Name}.");
                    Console.WriteLine($" Kan tages om: {canBeTakenHours}");
                    Console.WriteLine($"Udløber den: {kit.ExpireDate}");
                    activeKitsBp.Add(kit.Name);
                }
            }
            #endregion

            #region KitsOptions
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("--- Kit options ---");
            Console.WriteLine("1. Opret buy kit");
            Console.WriteLine("2. Opret BP kit");
            Console.WriteLine("3. Fjern kit(Rare usecase)");
            Console.WriteLine("4. Tag kit");
            Console.WriteLine("5. Set kit cooldown til et specifikt tidspukt OBS !!! Er ikke lavet endnu");
            Console.WriteLine("x/Enter. Gå tilbage");
            Console.Write("--> ");
            var userinput2 = 0;
            int.TryParse(Console.ReadLine(), out userinput2);
            #endregion

            if (userinput2 == 1)
            {
                #region KitOptionAddKitBuy
                Console.WriteLine("\n");
                Console.WriteLine("-- Hvilket kit? --");
                if (activeKits.Contains("Madchemist"))
                {
                    await ThrowErrorAsyncInline("1. Madchemist, (Det har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("1. Madchemist");
                }

                if (activeKits.Contains("Legend"))
                {
                    await ThrowErrorAsyncInline("2. Legend, (Det har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("2. Legend");
                }

                if (activeKits.Contains("Titan"))
                {
                    await ThrowErrorAsyncInline("3. Titan, (Det har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("3. Titan");
                }

                if (activeKits.Contains("Op"))
                {
                    await ThrowErrorAsyncInline("4. Op, (Det har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("4. Op");
                }

                if (activeKits.Contains("Konge"))
                {
                    await ThrowErrorAsyncInline("5. Konge, (Det har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("5. Konge");
                }

                if (activeKits.Contains("Bf"))
                {
                    await ThrowErrorAsyncInline("6. Bf, (Det har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("6. Bf");
                }

                if (activeKits.Contains("Key"))
                {
                    await ThrowErrorAsyncInline("7. Key, (Det har du allerade)").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("7. Key");
                }

                Console.WriteLine("x/Enter. Gå tilbage");
            retry:;
                Console.Write("--> ");
                var userInput3 = 0;
                int.TryParse(Console.ReadLine(), out userInput3);
                bool wasSaved = false;
                if (userInput3 == 1)
                {
                    if (activeKits.Contains("Madchemist"))
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine($"Du har allerade kit Madchemist");
                        goto retry;
                    }
                    else
                    {
                        // add kit 
                        var newKit = new KitNeverExpire { Name = "Madchemist", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(1) };
                        await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                        wasSaved = true;
                    }
                }
                if (userInput3 == 2)
                {
                    if (activeKits.Contains("Legend"))
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine($"Du har allerade kit Legend");
                        goto retry;
                    }
                    else
                    {
                        // add kit 
                        var newKit = new KitNeverExpire { Name = "Legend", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(1) };
                        await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                        wasSaved = true;
                    }
                }
                if (userInput3 == 3)
                {
                    if (activeKits.Contains("Titan"))
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine($"Du har allerade kit Titan");
                        goto retry;
                    }
                    else
                    {
                        // add kit 
                        var newKit = new KitNeverExpire { Name = "Titan", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(1) };
                        await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                        wasSaved = true;
                    }
                }
                if (userInput3 == 4)
                {
                    if (activeKits.Contains("Op"))
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine($"Du har allerade kit Op");
                        goto retry;
                    }
                    else
                    {
                        // add kit 
                        var newKit = new KitNeverExpire { Name = "Op", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(2) };
                        await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                        wasSaved = true;
                    }
                }
                if (userInput3 == 5)
                {
                    if (activeKits.Contains("Konge"))
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine($"Du har allerade kit Konge");
                        goto retry;
                    }
                    else
                    {
                        // add kit 
                        var newKit = new KitNeverExpire { Name = "Konge", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(2) };
                        await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                        wasSaved = true;
                    }
                }
                if (userInput3 == 6)
                {
                    if (activeKits.Contains("Bf"))
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine($"Du har allerade kit Bf");
                        goto retry;
                    }
                    else
                    {
                        // add kit 
                        var newKit = new KitNeverExpire { Name = "Bf", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(2) };
                        await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                        wasSaved = true;
                    }
                }
                if (userInput3 == 7)
                {
                    if (activeKits.Contains("Key"))
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine($"Du har allerade kit Key");
                        goto retry;
                    }
                    else
                    {
                        // add kit 
                        var newKit = new KitNeverExpire { Name = "Key", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(4) };
                        await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                        wasSaved = true;
                    }
                }
                if (!wasSaved)
                {
                    await ThrowErrorAsyncInline($"Ugyldigt input: {userInput3}").ConfigureAwait(false);
                    Thread.Sleep(1000);
                }
                wasSaved = false;
              
                goto displayKitsMenu;
                #endregion
            }

            if (userinput2 == 2)
            {
                #region KitOptionAddKitBp
                bool wasSaved = false;  
                Console.WriteLine("\n");
                Console.WriteLine("-- Hvilket kit? --");
                if (activeKitsBp.Contains("Kit head"))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("1. Kit head(Det har du allerade)");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.WriteLine("1. Kit head");
                }


                if (activeKitsBp.Contains("Kit tools"))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("2. Kit tools(Det har du allerade)");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.WriteLine("2. Kit tools");
                }


                if (activeKitsBp.Contains("Kit dollar"))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("3. Kit dollar(Det har du allerade)");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.WriteLine("3. Kit dollar");
                }




                Console.WriteLine("x/Enter. Gå tilbage");
            retry:;
                Console.Write("--> ");
                var userInput4 = 0;
                int.TryParse(Console.ReadLine(), out userInput4);

                if (userInput4 == 1)
                {
                    if (activeKitsBp.Contains("Kit head"))
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine($"Du har allerade kit head");
                        goto retry;
                    }
                    else
                    {
                        var newKit = new BpKit { Name = "Kit head", LastTaken = DateTime.Now, ExpireDate = DateTime.Now.AddDays(7) };
                        context.BpKits.Add(newKit);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                        wasSaved = true;
                    }
                }
                if (userInput4 == 2)
                {
                    if (activeKitsBp.Contains("Kit tools"))
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine($"Du har allerade kit tools");
                        goto retry;
                    }
                    else
                    {
                        var newKit = new BpKit { Name = "Kit tools", LastTaken = DateTime.Now, ExpireDate = DateTime.Now.AddDays(7) };
                        context.BpKits.Add(newKit);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                        wasSaved = true;
                    }
                }
                if (userInput4 == 3)
                {
                    if (activeKitsBp.Contains("Kit dollar"))
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine($"Du har allerade kit dollar");
                        goto retry;
                    }
                    else
                    {
                        var newKit = new BpKit { Name = "Kit dollar", LastTaken = DateTime.Now, ExpireDate = DateTime.Now.AddDays(7) };
                        context.BpKits.Add(newKit);
                        await context.SaveChangesAsync().ConfigureAwait(false);
                        wasSaved = true;
                    }
                }
                if (!wasSaved)
                {
                    await ThrowErrorAsyncInline($"Ugyldigt input: {userInput4}").ConfigureAwait(false);
                    Thread.Sleep(1000);
                }
                wasSaved = false;

                goto displayKitsMenu;
                #endregion
            }

            if (userinput2 == 3)
            {
                #region KitOptionRemoveKitRareUseCase
                Console.WriteLine("\n");
                Console.WriteLine("-- Kits --");
                await foreach (var kit in kitsDontExpire)
                {
                    Console.WriteLine(kit.Id + ". " + kit.Name);
                }
                Console.WriteLine("\n");
                Console.WriteLine("-- Bp Kits --");
                await foreach (var kit in bpKits)
                {
                    Console.WriteLine(kit.Id + ". " + kit.Name);
                }
                Console.WriteLine("\n");
                Console.WriteLine("Hvilken kategorig vil du slette fra? kits: 1 / Bp kits: 2");
                Console.Write("--> ");
                var category = 0;
                int.TryParse(Console.ReadLine(), out category);
                if (category != 1 && category != 2)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Invalid kategorig indtasted: {category}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Thread.Sleep(1000);
                    Console.Clear();
                    goto displayKitsMenu;
                }
                //validate input 
                Console.Write("Kit nummer --> ");

                var userInput5 = 0;
                int.TryParse(Console.ReadLine(), out userInput5);
                // validate 

                //validate. cant be null
                //cant be null. validate
                //var kitToRemove = context.kitNeverExpires.Find(userInput5);
                bool wasSaved = false;
          
                if (category == 1)
                {
                    await foreach (var kit in kitsDontExpire)  // get from db 
                    {
                        if (kit.Id == userInput5)
                        {
                            context.kitNeverExpires.Remove(kit);
                            wasSaved = true;
                        }
                    }
                    if (!wasSaved)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($" ERR! - Kunne ikke finde et kit med id {userInput5}");
                        Console.ForegroundColor = ConsoleColor.White;
                        Thread.Sleep(1000);
                    }
                    wasSaved = false;

                }
                if (category == 2)
                {
                    await foreach (var kit in bpKits)   // get from async db service 
                    {
                        if (kit.Id == userInput5)
                        {
                            context.BpKits.Remove(kit);
                            wasSaved = true;
                        }
                    }
                    if (!wasSaved)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($" ERR! - Kunne ikke finde et kit med id {userInput5}");
                        Console.ForegroundColor = ConsoleColor.White;
                        Thread.Sleep(1000);
                    }
                    wasSaved = false;
                }


                await context.SaveChangesAsync().ConfigureAwait(false);

                Console.Clear();
                goto displayKitsMenu;
                #endregion
            }

            if (userinput2 == 4)
            {
                #region KitOptionTakeKit
            retry:;
                Console.WriteLine("\n");
                Console.WriteLine("(1)-- Kits --");
                await foreach (var kit in kitsDontExpire)
                {
                    Console.WriteLine(kit.Id + ". " + kit.Name);
                }
                Console.WriteLine("\n");
                Console.WriteLine("(2)-- Bp Heads --");
                await foreach (var kit in bpKits)
                {
                    Console.WriteLine(kit.Id + ". " + kit.Name);
                }


                Console.WriteLine("\n");
                Console.WriteLine("Hvilken kategorig vil du tage fra? kits: 1 / Bp kits: 2");
                Console.Write("--> ");
                var category = 0;
                int.TryParse(Console.ReadLine(), out category);
                if (category != 1 && category != 2)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Invalid kategorig indtasted: {category}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Thread.Sleep(1000);
                    Console.Clear();
                    goto displayKitsMenu;
                }
            Repeat:;
                Console.WriteLine("f. færdig");
                Console.Write("Kit nummer --> ");
                var userInput6 = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(userInput6)) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("ERROR. Invalid ID. Try again."); Console.ForegroundColor = ConsoleColor.White; goto Repeat; }
                if (userInput6 == "f") { Console.Clear(); goto displayKitsMenu; } // DONE  
                else
                {
                    if (!int.TryParse(userInput6, out int userInputToInt))
                    {
                        Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("ERROR. Invalid ID. Try again."); Console.ForegroundColor = ConsoleColor.White; goto Repeat;
                    }
                    
                    bool wasSaved = false;

                    if (category == 1)
                    {
                        await foreach (var kit in kitsDontExpire)
                        {
                            if (kit.Id == userInputToInt)
                            {
                                await asyncDbTasks.SaveNEKitAsync(kit).ConfigureAwait(false);   // not correctly saving 
                                wasSaved = true;
                                Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("Kit blev opdateret:)"); Console.ForegroundColor = ConsoleColor.White;
                            }
                        }


                        if (!wasSaved)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($" ERR! - Kunne ikke finde et kit med id {userInput6}");
                            Console.ForegroundColor = ConsoleColor.White;
                            Thread.Sleep(1000);
                        }
                        wasSaved = false;
                    }
                    if (category == 2)
                    {

                        await foreach (var kit in bpKits)
                        {
                            if (kit.Id == userInputToInt)
                            {
                                await asyncDbTasks.SaveBpKitAsync(kit).ConfigureAwait(false);
                                wasSaved = true;
                                Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("Kit blev opdateret:)"); Console.ForegroundColor = ConsoleColor.White;
                            }
                        }

                        if (!wasSaved)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($" ERR! - Kunne ikke finde et kit med id {userInput6}");
                            Console.ForegroundColor = ConsoleColor.White;
                            Thread.Sleep(1000);
                        }
                        wasSaved = false;
                    }

                    goto Repeat;
                }
                #endregion
            }
        }
    }
    catch(Exception ex)
    {
        Console.WriteLine("An error occurred in DisplayKits. Please contect the dev.");
        Console.ReadLine();
    }
}

async Task ThrowErrorAsyncInline(string message)
{
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(message);
        Console.ForegroundColor = ConsoleColor.White;
}





static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
{
    LogError((Exception)e.ExceptionObject);
    Console.WriteLine("An error occurred. Please contect the dev.");
    Console.ReadLine();
}

static void TaskScheduler_UnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs e)
{
    LogError(e.Exception);
    Console.WriteLine("An error occurred. Please contact the dev.");
    e.SetObserved();
    Console.ReadLine();
}

 static void LogError(Exception ex)
{
    File.AppendAllText("errorLog.txt", $"{DateTime.Now} - {ex.ToString()}\n");
}

