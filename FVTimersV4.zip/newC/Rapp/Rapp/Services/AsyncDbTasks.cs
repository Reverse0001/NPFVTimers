﻿using Microsoft.EntityFrameworkCore;
using Rapp.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rapp.Services
{

    public static class CompiledQueries
    {
        public static readonly Func<DbService, IAsyncEnumerable<Invistering>> GetInvisteringerStreamAsync =
            EF.CompileAsyncQuery((DbService context) =>
            context.Invisteringer);

        public static readonly Func<DbService, string, Task<Invistering>> GetInvisteringAsTrackingAsync =
         EF.CompileAsyncQuery((DbService context, string investeringName) =>
             context.Invisteringer.AsTracking().FirstOrDefault(i => i.Name == investeringName)
                 );

        public static readonly Func<DbService, int, Task<Invistering>> GetSingleInvesteringByIdAsync =
      EF.CompileAsyncQuery((DbService context, int invisteringId) =>
          context.Invisteringer.AsTracking().FirstOrDefault(i => i.Id == invisteringId)
              );

        public static readonly Func<DbService, IAsyncEnumerable<BpKit>> GetBpKitsStreamAsync =
          EF.CompileAsyncQuery((DbService context) =>
          context.BpKits.AsNoTracking());

        public static readonly Func<DbService, IAsyncEnumerable<KitNeverExpire>> GetKitsAsync =
            EF.CompileAsyncQuery((DbService context) =>
            context.kitNeverExpires.AsNoTracking());

        public static readonly Func<DbService, int, Task<KitNeverExpire>> GetNEKitAsyncViaId =
            EF.CompileAsyncQuery((DbService context, int id) =>
                context.kitNeverExpires.FirstOrDefault(i => i.Id == id));

        public static readonly Func<DbService, int, Task<BpKit>> GetBpKitAsyncViaId =
            EF.CompileAsyncQuery((DbService context, int id) =>
                context.BpKits.FirstOrDefault(i => i.Id == id));

        public static readonly Func<DbService, int, Task<Grund>> GetSingleGrundViaIdAsync =
            EF.CompileAsyncQuery((DbService context, int id) =>
                context.Grunde.FirstOrDefault(g => g.Id == id));

        public static readonly Func<DbService, string, Task<Grund>> GetSingleGrundAsync =
            EF.CompileAsyncQuery((DbService context, string grundName) =>
                context.Grunde.AsNoTracking().FirstOrDefault(g => g.Name == grundName)
                    );
        public static readonly Func<DbService, string, Task<Grund>> GetGrundAsyncAsTracking =
          EF.CompileAsyncQuery((DbService context, string grundName) =>
              context.Grunde.AsTracking().FirstOrDefault(g => g.Name == grundName)
                  );

        public static readonly Func<DbService, IAsyncEnumerable<Grund>> GetGrundeStreamAsync =
          EF.CompileAsyncQuery((DbService context) =>
          context.Grunde.AsNoTracking());

        public static readonly Func<DbService, Task<Settings>> GetSettingsAsync =
            EF.CompileAsyncQuery((DbService context) =>
                context.Settings.FirstOrDefault());

    }
    public class AsyncDbTasks
    {

        public async IAsyncEnumerable<Grund> GetGrundeStreamAsync()
        {
            using (var context = new DbService())
            {

                await foreach (var item in CompiledQueries.GetGrundeStreamAsync(context).ConfigureAwait(false))
                {
                    yield return item;
                }
            }
        }
        public async IAsyncEnumerable<Invistering> GetInvisteringerStreamAsync()
        {
            using (var context = new DbService())
            {
                await foreach (var item in CompiledQueries.GetInvisteringerStreamAsync(context))
                {
                    yield return item;
                }
            }
        }
        public async IAsyncEnumerable<BpKit> GetBpKitsStreamAsync()
        {
            using (var context = new DbService())
            {
                await foreach (var item in CompiledQueries.GetBpKitsStreamAsync(context))
                {
                    yield return item;
                }
            }
        }
        public async IAsyncEnumerable<KitNeverExpire> GetKitsAsync()
        {
            using (var context = new DbService())
            {
                await foreach (var item in CompiledQueries.GetKitsAsync(context))
                {
                    yield return item;
                }
            }
        }



        public async Task<Grund> GetGrundAsTrackingAsync(DbService context, string grundNavn)
        {
            return await CompiledQueries.GetGrundAsyncAsTracking(context, grundNavn).ConfigureAwait(false);
        }
        public async Task<Grund> SaveGrundAsync(DateTime newDate, Grund grundToUpdate)
        {
            using (var context = new DbService())
            {
                var FetchGrundFromDb = await CompiledQueries.GetSingleGrundViaIdAsync(context, grundToUpdate.Id).ConfigureAwait(false);
                FetchGrundFromDb.LastTimeDaysWereAddedDate = newDate;
                await context.SaveChangesAsync().ConfigureAwait(false);
                return null;
            }
        }
        public async Task<Grund> SetExpireDateManuallyAsync(string name, int dage, int timer)
        {
            using (var context = new DbService())
            {
                DateTime LastAdded = DateTime.Now.AddDays(-(9 - dage)).AddHours(-(23 - timer));
                var grundTóUpdate = await GetGrundAsTrackingAsync(context, name).ConfigureAwait(false);
                grundTóUpdate.LastTimeDaysWereAddedDate = LastAdded;
                await context.SaveChangesAsync().ConfigureAwait(false);
                return null;
            }
        }
        public async Task<Grund> GetSingleGrundAsync(string grundNavn)
        {
            using (var context = new DbService())
            {
                return await CompiledQueries.GetSingleGrundAsync(context, grundNavn).ConfigureAwait(false);

            }
        }



        public async Task<Invistering> GetInvisteringAsTrackingAsync(string investeringName)
        {
            using (var context = new DbService())
            {
                return await CompiledQueries.GetInvisteringAsTrackingAsync(context, investeringName);
            }
        }
        public async Task<Invistering> GetSingleInvesteringAsyncAsTrackingById(int invisteringId)
        {
            using (var context = new DbService())
            {
                return await CompiledQueries.GetSingleInvesteringByIdAsync(context, invisteringId);
            }
        }
        public async Task<Invistering> GetSingleInvesteringAsyncAsTracking(DbService context, int id)
        {
            return await CompiledQueries.GetSingleInvesteringByIdAsync(context, id);
        }
        public async Task<Invistering> SaveInvisteringAsync(Invistering invisteringToUpdate)
        {
            using (var context = new DbService())
            {
                var fetchInvisteringFromDb = await context.Invisteringer.FirstOrDefaultAsync(i => i.Id == invisteringToUpdate.Id).ConfigureAwait(false);
                fetchInvisteringFromDb.LastTakenDate = DateTime.Now;
                await context.SaveChangesAsync().ConfigureAwait(false);
                return null;
            }
        }
        public async Task<Invistering> SetExpireDatemanuallyInvistAsync(int id, int dage, int timer, int min)
        {
            using (var context = new DbService())
            {

                //add days uses - -   but the others uses add technally as i max versus input. must be looked into 
                DateTime lastAdded = DateTime.Now.AddDays(-(9 - dage)).AddHours(-(23 - timer)).AddMinutes(-(59 - min));
                var invistToUpdate = await GetSingleInvesteringAsyncAsTracking(context, id).ConfigureAwait(false);  //works without injecting current context? 
                invistToUpdate.LastTakenDate = lastAdded;
                await context.SaveChangesAsync().ConfigureAwait(false);
                return null;

            }
        }



        public async Task<KitNeverExpire> SaveNEKitAsync(KitNeverExpire kitNeverExpire)
        {
            using (var context = new DbService())
            {
                var fetchKitFormDb = await CompiledQueries.GetNEKitAsyncViaId(context, kitNeverExpire.Id).ConfigureAwait(false);
                if (fetchKitFormDb.Name == "Key")
                {
                    fetchKitFormDb.LastTaken = DateTime.Now;
                    fetchKitFormDb.CanBeTaken = DateTime.Now.AddDays(4);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                else if (fetchKitFormDb.Name == "Op")
                {
                    fetchKitFormDb.LastTaken = DateTime.Now;
                    fetchKitFormDb.CanBeTaken = DateTime.Now.AddDays(2);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                else if (fetchKitFormDb.Name == "Konge")
                {
                    fetchKitFormDb.LastTaken = DateTime.Now;
                    fetchKitFormDb.CanBeTaken = DateTime.Now.AddDays(2);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                else if (fetchKitFormDb.Name == "Bf")
                {
                    fetchKitFormDb.LastTaken = DateTime.Now;
                    fetchKitFormDb.CanBeTaken = DateTime.Now.AddDays(2);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                else
                {
                    fetchKitFormDb.LastTaken = DateTime.Now;
                    fetchKitFormDb.CanBeTaken = DateTime.Now.AddDays(1);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                return null;
            }
        }
        public async Task<KitNeverExpire> SetExpireDatemanuallyKitNEAsync(int id, int dage, int timer, int min)
        {
            using (var context = new DbService())
            {

                var kitToUpdate = await CompiledQueries.GetNEKitAsyncViaId(context, id).ConfigureAwait(false);
                if (kitToUpdate.Name == "Key")
                {
                    DateTime lastAdded = DateTime.Now.AddDays(-(3 - dage)).AddHours(-(23 - timer)).AddMinutes(-(59 - min));
                    kitToUpdate.LastTaken = lastAdded;
                    kitToUpdate.CanBeTaken = lastAdded.AddDays(4);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                else if (kitToUpdate.Name == "Op")
                {
                    DateTime lastAdded = DateTime.Now.AddDays(-(1 - dage)).AddHours(-(23 - timer)).AddMinutes(-(59 - min));
                    kitToUpdate.LastTaken = lastAdded;
                    kitToUpdate.CanBeTaken = lastAdded.AddDays(2);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                else if (kitToUpdate.Name == "Konge")
                {
                    DateTime lastAdded = DateTime.Now.AddDays(-(1 - dage)).AddHours(-(23 - timer)).AddMinutes(-(59 - min));
                    kitToUpdate.LastTaken = lastAdded;
                    kitToUpdate.CanBeTaken = lastAdded.AddDays(2);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                else if (kitToUpdate.Name == "Bf")
                {
                    DateTime lastAdded = DateTime.Now.AddDays(-(1 - dage)).AddHours(-(23 - timer)).AddMinutes(-(59 - min));
                    kitToUpdate.LastTaken = lastAdded;
                    kitToUpdate.CanBeTaken = lastAdded.AddDays(2);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
                else
                {
                    DateTime lastAdded = DateTime.Now.AddHours(-(23 - timer)).AddMinutes(-(59 - min));
                    kitToUpdate.LastTaken = lastAdded;
                    kitToUpdate.CanBeTaken = lastAdded.AddDays(1);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }

                return null;

            }
        }
        public async Task<BpKit> SetExpireDatemanuallyBPKitasync(int id, int timer, int min)
        {
            using (var context = new DbService())
            {

                var kitToUpdate = await CompiledQueries.GetBpKitAsyncViaId(context, id).ConfigureAwait(false);
                DateTime lastAdded = DateTime.Now.AddHours(-(23 - timer)).AddMinutes(-(59 - min));
                kitToUpdate.LastTaken = lastAdded;
                await context.SaveChangesAsync().ConfigureAwait(false);

                return null;

            }
        }
        public async Task<BpKit> SaveBpKitAsync(BpKit bpKit)
        {
            using (var context = new DbService())
            {
                var fetchKitFromDb = await CompiledQueries.GetBpKitAsyncViaId(context, bpKit.Id).ConfigureAwait(false);
                fetchKitFromDb.LastTaken = DateTime.Now;
                await context.SaveChangesAsync().ConfigureAwait(false);
                return null;
            }
        }



        public async Task<Settings> SaveSettings(int errorMessageDisplay, int succMessageDisplay)
        {
            using (var context = new DbService())
            {

                var settings = await CompiledQueries.GetSettingsAsync(context).ConfigureAwait(false);
                if (settings.ErrorMessageDisplayTime != errorMessageDisplay)
                {
                    settings.ErrorMessageDisplayTime = errorMessageDisplay;
                }
                if (settings.SuccessMessageDisplayTime != succMessageDisplay)
                {
                    settings.SuccessMessageDisplayTime = succMessageDisplay;
                }
                await context.SaveChangesAsync().ConfigureAwait(false);
                return null;

            }
        }

         
    }
}
