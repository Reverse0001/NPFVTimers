﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Tokens;
using Rapp.Models;
using Rapp.Services;
using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Threading;
using System.Xml;


// Lol læs koden på eget ansvar. Sgu da ikke fordi jeg magter ryde det op.
// disclaimer:) Nu er du advaret

// add min to all place where set time speceik onl takes day and hour 
//value task 
try
{

    #region OnInit
    var userInput = 0;
    var asyncDbTasks = new AsyncDbTasks();

    AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
    TaskScheduler.UnobservedTaskException += TaskScheduler_UnobservedTaskException;

    #region UserResponces 
    var errTastTal = "Du skal taste et tal";
    var errKitMissingId = "Kunne ikke finde et kit med id:";
    var errKitAlreadyOwned = "Det kit har du allerede";
    var errMissingCategory = "Kunne ikke finde en kategori med id:";
    var errInvesteringAlreadyOwned = "Du har allerede den investering";
    var errInvesteringMissingId = "Kunne ikke finde en investering med id:";
    var errNumberOfF = "Du skal taste et tal eller 'f'";

    var succgrundChanged = "Grunden blev opdateret";
    var succGrundDaysAdded = "Grunden har fået flere dage";
    var succGrundSlettet = "Grunden blev fjernet";
    var errGrundCouldentFindName = "Kunne ikke finde en grund med navnet:";
    var succGrundAdded = "Din grund blev oprettet";
    var errgrundNeedsName = "Din grund skal have et navn";
    var errGrundNameUnik = "Dine grunde skal have unikke navne";
    var warnInputZero = "WARNING: Dit input er registreret som 0";

    var errSettingsNoMatchId = "Kunne ikke finde en setting med id:";
    var succSettingsSavedChanged = "Dine ændringer er blevet gemt";

    var succInvisteringRemoved = "Investeringen blev fjernet";
    var succInvesteringAdded = "Investering blev tilføjet";
    var succInvesteringTaget = "Investeringen blev taget";

    var succKitRemoved = "Kit er blevet slettet";
    var succKitChanged = "Kit blev opdateret";
    var succKitAdded = "Kit blev tilføjet";
    var succKitTaget = "Kit blev taget";
    #endregion


    var settings = new Settings();
    using (var context = new DbService())
    {
        settings = await context.Settings.FirstOrDefaultAsync().ConfigureAwait(false);
        if (settings == null)
        {
            var initSettings = new Settings { ErrorMessageDisplayTime = 1000, SuccessMessageDisplayTime = 300 };
            await context.Settings.AddAsync(initSettings).ConfigureAwait(false);
            await context.SaveChangesAsync().ConfigureAwait(false);
            settings = await context.Settings.FirstOrDefaultAsync().ConfigureAwait(false);
        }
    }


    #endregion

    while (true)
    {
        await DisplayMainMenu().ConfigureAwait(false);
        int.TryParse(Console.ReadLine(), out userInput);

        if (userInput == 1)
        {
            await DisplayGrundeMenu().ConfigureAwait(false);
        }
        else if (userInput == 2)
        {
            await DisplayInvisteringer().ConfigureAwait(false);
        }
        else if (userInput == 3)
        {
            await DisplayKits().ConfigureAwait(false);
        }
        else if (userInput == 4)
        {
            await DisplaySettings().ConfigureAwait(false);
        }
        Console.Clear();
    }

    async Task DisplayMainMenu()
    {
        Console.WriteLine("FV Dashboard");
        Console.WriteLine("\n");
        Console.WriteLine("--- Options ---");
        Console.WriteLine("1. Grunde.");
        Console.WriteLine("2. Investeringer.");
        Console.WriteLine("3. Kits.");
        Console.WriteLine("4. Settings.");
        Console.Write("--> ");
    }
    async Task DisplayGrundeMenu()
    {
    grundeLabel:;
        using (var context = new DbService())
        {
            #region DisplayGrundeMenuOnInit
            Console.Clear();
            var asyncDbTaskss = new AsyncDbTasks();
            var grunde = asyncDbTaskss.GetGrundeStreamAsync().ConfigureAwait(false);
            Console.WriteLine("     --- Dine Grunde ---");
            #endregion

            #region DisplayGrundTemplate
            await foreach (var grund in grunde)
            {
                if (grund.LastTimeDaysWereAddedDate.AddDays(9) < DateTime.Now)
                {
                    Console.WriteLine("---------------------------------");
                    Console.Write($"Navn:");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($" {grund.Name}.");
                    Console.WriteLine($"Gruden løb tør for dage:(");
                }
                var dagee2 = grund.LastTimeDaysWereAddedDate + TimeSpan.FromDays(9);
                var tilbage = (dagee2 - DateTime.Now).TotalDays;
                Console.WriteLine("---------------------------------");
                Console.Write($"Navn:");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine($" {grund.Name}.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"Udløber den:");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($" {dagee2}(Tidligst)");
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write($"Udløber om:");
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($" {tilbage}, dage(Tidligst)");
                Console.ForegroundColor = ConsoleColor.White;
                if (tilbage <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart. Add dage."); goto skipState; }
                if (tilbage <= 7) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Kunne være du skulle overveje at adde dage"); goto skipState; }
                if (tilbage <= 10) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer for at den udløber"); goto skipState; }
            skipState:;
                Console.ForegroundColor = ConsoleColor.White;
            }
            #endregion

            #region GrundeOptions
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("--- Options ---");
            Console.WriteLine("1. Add Grund");
            Console.WriteLine("2. Del Grund");
            Console.WriteLine("3. AddDays Grund");
            Console.WriteLine("4. Sæt specifik tid på Grund");
            Console.WriteLine("X/Enter. Gå tilbage");
            Console.Write("--> ");
            var userInput2 = 0;
            int.TryParse(Console.ReadLine(), out userInput2);
            #endregion

            if (userInput2 == 1)
            {
                #region GrundOptionAddGrund
            tryagain:;
                Console.WriteLine("Fortryd?: f");
                Console.Write("Grund Navn --> ");
                var grundNavn = Console.ReadLine();
                if (grundNavn == "f") { Console.Clear(); goto grundeLabel; }
                else
                {
                    if (String.IsNullOrWhiteSpace(grundNavn)) { await ThrowErrorAsyncInline(errgrundNeedsName).ConfigureAwait(false); goto tryagain; }
                    await foreach (var grund in grunde)
                    {
                        if (grund.Name == grundNavn) { await ThrowErrorAsyncInline(errGrundNameUnik).ConfigureAwait(false); goto tryagain; }
                    }
                    var grundSomAddes = new Grund()
                    {
                        Name = grundNavn,
                        LastTimeDaysWereAddedDate = DateTime.Now,
                    };

                    await ThrowSleepySuccessAsyncInline(succGrundAdded).ConfigureAwait(false);

                    await context.Grunde.AddAsync(grundSomAddes).ConfigureAwait(false);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                    goto grundeLabel;
                }
                #endregion
            }

            if (userInput2 == 2)
            {
                #region GrundOptionRemoveGrund

            delgrundretry:;
                bool wasDeleted = false;
                Console.WriteLine("Fortryd?: f");
                Console.Write("Slet grund med navnet --> ");
                var grundToDelete = Console.ReadLine();
                if (grundToDelete == "f") { Console.Clear(); goto grundeLabel; }
                else
                {
                    if (String.IsNullOrWhiteSpace(grundToDelete)) { await ThrowErrorAsyncInline(errgrundNeedsName).ConfigureAwait(false); goto delgrundretry; }
                    await foreach (var grund in grunde)
                    {
                        if (grund.Name == grundToDelete)
                        {
                            context.Remove(grund);
                            wasDeleted = true;
                        }
                    }
                    await context.SaveChangesAsync().ConfigureAwait(false);
                    if (wasDeleted == false) { await ThrowErrorAsyncInline($"{errGrundCouldentFindName} {grundToDelete}").ConfigureAwait(false); goto delgrundretry; }
                    else if (wasDeleted) { await ThrowSleepySuccessAsyncInline(succGrundSlettet).ConfigureAwait(false); }

                    goto grundeLabel;

                }
                #endregion
            }

            if (userInput2 == 3)
            {
                #region GrundOptionAddDays
            retryyy:;
                Console.WriteLine("Fortryd?: f");
                Console.Write("Hvilken grund(navn)? --> ");
                var grundNavn = Console.ReadLine();
                if (grundNavn == "f")
                {
                    goto grundeLabel;
                }
                else
                {
                    if (String.IsNullOrWhiteSpace(grundNavn)) { await ThrowErrorAsyncInline(errgrundNeedsName).ConfigureAwait(false); goto retryyy; }
                    var grundDerSkalOpdateres = await asyncDbTasks.GetSingleGrundAsync(grundNavn).ConfigureAwait(false);
                    if (grundDerSkalOpdateres == null) { await ThrowErrorAsyncInline($"{errGrundCouldentFindName} {grundNavn}").ConfigureAwait(false); goto retryyy; }
                    await asyncDbTasks.SaveGrundAsync(DateTime.Now, grundDerSkalOpdateres).ConfigureAwait(false);
                    await ThrowSleepySuccessAsyncInline(succGrundDaysAdded).ConfigureAwait(false);

                    goto grundeLabel;
                }

                #endregion
            }
            if (userInput2 == 4)
            {
                #region GrundOptionSetTimer
            retryyyyyy:;
                Console.WriteLine("Fortryd?: f");
                Console.Write("Hvilken grund(navn)? --> ");
                var grundNavn = Console.ReadLine();
                if (grundNavn == "f")
                {
                    goto grundeLabel;
                }
                else
                {
                    if (String.IsNullOrWhiteSpace(grundNavn)) { await ThrowErrorAsyncInline(errgrundNeedsName).ConfigureAwait(false); goto retryyyyyy; }
                    var grundDerSkalOpdateres = await asyncDbTasks.GetSingleGrundAsync(grundNavn).ConfigureAwait(false);
                    if (grundDerSkalOpdateres == null) { await ThrowErrorAsyncInline($"{errGrundCouldentFindName} {grundNavn}").ConfigureAwait(false); goto retryyyyyy; }

                    var setDays = 9;
                    Console.Write("Sæt dage til --> ");
                    int.TryParse(Console.ReadLine(), out setDays);
                    if (setDays == 0) { await ThrowErrorAsyncInline($"Ugyldigt input: {setDays}").ConfigureAwait(false); Thread.Sleep(1000); goto grundeLabel; }
                    Console.Write("Sæt timer til --> ");
                    var setHours = 23;
                    int.TryParse(Console.ReadLine(), out setHours);
                    if (setDays == 0) { await ThrowErrorAsyncInline($"Ugyldigt input: {setDays}").ConfigureAwait(false); Thread.Sleep(1000); goto grundeLabel; }
                    await asyncDbTasks.SetExpireDateManuallyAsync(grundDerSkalOpdateres.Name, setDays, setHours).ConfigureAwait(false);
                    await ThrowSleepySuccessAsyncInline(succgrundChanged).ConfigureAwait(false);
                    goto grundeLabel;
                }
                #endregion
            }
        }
    }
    async Task DisplayInvisteringer()
    {

    InvisteringerMainMenn:;
        using (var context = new DbService())
        {
            #region DisplayInvisteringerOnInit 
            Console.Clear();
            var invisteringer = asyncDbTasks.GetInvisteringerStreamAsync();
            Console.WriteLine("--- Invisteringer ---");
            var activeInvestments = new List<string>();
            #endregion

            #region DisplayInvisteringerTemplate 
            await foreach (var item in invisteringer)
            {
                DateTime Udlllob = item.LastTakenDate.AddDays(10);
                DateTime targetTime = item.LastTakenDate.AddHours(24);
                TimeSpan kanTagesOm = targetTime - DateTime.Now;
                var udlooberOm = (Udlllob - DateTime.Now).TotalDays;
                activeInvestments.Add(item.Name);
                if (Udlllob < DateTime.Now)
                {
                    Console.WriteLine("---------------------------------");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"Invisterings navn: ");
                    Console.WriteLine($"{item.Name}");
                    Console.WriteLine("Investeringen løb ud:(");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else if (targetTime < DateTime.Now)
                {
                    Console.WriteLine("---------------------------------");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Invisterings navn: ");
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($"{item.Name}");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Invisterings nummer: ");
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"{item.Id}");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Denne invistering er klar!:D");
                    Console.Write($"Udløber om: ");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"{udlooberOm}, Dage");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Udløber den: ");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"{item.LastTakenDate.AddDays(10)}");
                    if (udlooberOm <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart"); goto skipState; }
                    if (udlooberOm <= 7) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Burde måske tage den snart"); goto skipState; }
                    if (udlooberOm <= 11) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer"); goto skipState; }
                skipState:;
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {

                    Console.WriteLine("---------------------------------");
                    Console.Write($"Invisterings navn: ");
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($"{item.Name}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"Invisterings nummer: ");
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"{item.Id}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"Kan tages om: ");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"{kanTagesOm}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"Udløber om: ");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"{udlooberOm}, Dage");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"Udløber den: ");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"{item.LastTakenDate.AddDays(10)}");
                    Console.ForegroundColor = ConsoleColor.White;
                    if (udlooberOm <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart"); goto skipState; }
                    if (udlooberOm <= 7) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Burde måske tage den snart"); goto skipState; }
                    if (udlooberOm <= 11) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer"); goto skipState; }
                skipState:;
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            #endregion

            #region InvisteringerOptinos 
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("--- Options ---");
            Console.WriteLine("1. Opret Invistering");
            Console.WriteLine("2. Slet Invisterings");
            Console.WriteLine("3. Tag Invistering");
            Console.WriteLine("4. Sæt Invisterings timer manuelt");
            Console.WriteLine("x/Enter. Gå tilbage");
            Console.Write("--> ");
            var userInput5 = 0;
            int.TryParse(Console.ReadLine(), out userInput5);
            #endregion

            if (userInput5 == 1)
            {
                #region InvisteringOptionAddInvistering
                Console.WriteLine("\n");
                Console.WriteLine(("--- Invisteringer du kan adde ---"));


                // TODO Consider using foreach 
                if (activeInvestments.Contains("Lego tower"))
                {
                    await ThrowErrorAsyncInline($"1. Lego tower. {errInvesteringAlreadyOwned}").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("1. Lego tower");
                }

                if (activeInvestments.Contains("V tower"))
                {
                    await ThrowErrorAsyncInline($"2. V tower. {errInvesteringAlreadyOwned}").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("2. V tower");
                }

                if (activeInvestments.Contains("The diner"))
                {
                    await ThrowErrorAsyncInline($"3. The diner. {errInvesteringAlreadyOwned}").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("3. The diner");
                }

                if (activeInvestments.Contains("Zazbar"))
                {
                    await ThrowErrorAsyncInline($"4. Zazbar. {errInvesteringAlreadyOwned}").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("4. Zazbar");
                }

                if (activeInvestments.Contains("Xpark"))
                {
                    await ThrowErrorAsyncInline($"5. Xpark. {errInvesteringAlreadyOwned}").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("5. Xpark");
                }

                if (activeInvestments.Contains("XenoCorp"))
                {
                    await ThrowErrorAsyncInline($"6. XenoCorp. {errInvesteringAlreadyOwned}").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("6. XenoCorp");
                }

                if (activeInvestments.Contains("AFK industries"))
                {
                    await ThrowErrorAsyncInline($"7. AFK industries. {errInvesteringAlreadyOwned}").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("7. AFK industries");
                }

                if (activeInvestments.Contains("DiaMinen"))
                {
                    await ThrowErrorAsyncInline($"8. DiaMinen. {errInvesteringAlreadyOwned}").ConfigureAwait(false);
                }
                else
                {
                    Console.WriteLine("8. DiaMinen");
                }



            InvisteringAddretry:;
                Console.Write("--> ");
                var userInput8 = 0;
                int.TryParse(Console.ReadLine(), out userInput8);
                bool wasAdded = false;
                switch (userInput8)
                {
                    case 0:
                        #region ThrowError
                        await ThrowSleepyErrorAsyncInline(errTastTal).ConfigureAwait(false);
                        goto InvisteringerMainMenn;

                    #endregion
                    case 1:
                        #region AddLegoTower
                        if (activeInvestments.Contains("Lego tower"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errInvesteringAlreadyOwned).ConfigureAwait(false);
                            goto InvisteringerMainMenn;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "Lego tower",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 2:
                        #region AddVTower
                        if (activeInvestments.Contains("V tower"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errInvesteringAlreadyOwned).ConfigureAwait(false);
                            goto InvisteringerMainMenn;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "V tower",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 3:
                        #region AddTheDiner
                        if (activeInvestments.Contains("The diner"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errInvesteringAlreadyOwned).ConfigureAwait(false);
                            goto InvisteringerMainMenn;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "The diner",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;

                            break;
                        }
                    #endregion
                    case 4:
                        #region AddZazbar
                        if (activeInvestments.Contains("Zazbar"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errInvesteringAlreadyOwned).ConfigureAwait(false);
                            goto InvisteringerMainMenn;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "Zazbar",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 5:
                        #region AddXpark
                        if (activeInvestments.Contains("Xpark"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errInvesteringAlreadyOwned).ConfigureAwait(false);
                            goto InvisteringerMainMenn;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "Xpark",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 6:
                        #region AddXenoCorp
                        if (activeInvestments.Contains("XenoCorp"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errInvesteringAlreadyOwned).ConfigureAwait(false);
                            goto InvisteringerMainMenn;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "XenoCorp",
                                LastTakenDate = DateTime.Now,

                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 7:
                        #region AddAFKindustries
                        if (activeInvestments.Contains("AFK industries"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errInvesteringAlreadyOwned).ConfigureAwait(false);
                            goto InvisteringerMainMenn;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "AFK industries",
                                LastTakenDate = DateTime.Now,
                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                    #endregion
                    case 8:
                        #region AddDiaMinen
                        if (activeInvestments.Contains("DiaMinen"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errInvesteringAlreadyOwned).ConfigureAwait(false);
                            goto InvisteringerMainMenn;
                        }
                        else
                        {
                            var newItem = new Invistering
                            {
                                Name = "DiaMinen",
                                LastTakenDate = DateTime.Now,
                            };
                            await context.Invisteringer.AddAsync(newItem).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasAdded = true;
                            break;
                        }
                        #endregion

                }
                if (wasAdded)
                {
                    await ThrowSleepySuccessAsyncInline(succInvesteringAdded).ConfigureAwait(false);
                    wasAdded = false;
                }
                else
                {
                    await ThrowSleepyErrorAsyncInline($"{errInvesteringMissingId} {userInput8}").ConfigureAwait(false);
                }
                goto InvisteringerMainMenn;
                #endregion
            }

            if (userInput5 == 2)
            {
                #region InvisteringOptionRemoveInvistering
                Console.WriteLine("\n");
                Console.Write("Slet invistering med nummer --> ");
                var userInput9 = 0;
                int.TryParse(Console.ReadLine(), out userInput9);
                if (userInput9 == 0) { await ThrowSleepyErrorAsyncInline(errTastTal).ConfigureAwait(false); goto InvisteringerMainMenn; }
                bool wasSaved = false;
                await foreach (var item in invisteringer)
                {
                    if (item.Id == userInput9) { context.Remove(item); wasSaved = true; }
                }
                if (wasSaved)
                {
                    await context.SaveChangesAsync().ConfigureAwait(false);
                    await ThrowSleepySuccessAsyncInline(succInvisteringRemoved).ConfigureAwait(false);
                }
                else
                {
                    await ThrowSleepyErrorAsyncInline($"{errInvesteringMissingId} {userInput9}");
                }
                wasSaved = false;
                goto InvisteringerMainMenn;
                #endregion
            }

            if (userInput5 == 3)
            {
                #region InvisteringOptionTakeInvistering

                Console.WriteLine("\n");
            Repeat:;
                Console.WriteLine("f. Færdig");
                Console.Write("Inviterings nummer --> ");
                var userInput6 = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(userInput6)) { await ThrowErrorAsyncInline(errNumberOfF).ConfigureAwait(false); goto Repeat; }
                if (userInput6 == "f") { Console.Clear(); goto InvisteringerMainMenn; }
                else
                {
                    if (!int.TryParse(userInput6, out int userInputToInt))
                    {
                        await ThrowErrorAsyncInline($"{errNumberOfF}").ConfigureAwait(false); goto Repeat;
                    }
                    bool wasSaved = false;

                    await foreach (var item in invisteringer)
                    {
                        if (item.Id == userInputToInt)
                        {
                            await asyncDbTasks.SaveInvisteringAsync(item).ConfigureAwait(false);
                            wasSaved = true;
                            await ThrowSleepySuccessAsyncInline(succInvesteringTaget).ConfigureAwait(false);
                        }
                    }

                    if (!wasSaved)
                    {
                        await ThrowErrorAsyncInline($"{errInvesteringMissingId} {userInput6}").ConfigureAwait(false);
                    }
                    wasSaved = false;

                    goto Repeat;
                }

                #endregion
            }

            if (userInput5 == 4)
            {
                #region InvisteringOptionSetspecificTimer

                Console.WriteLine("\n");
                Console.Write("hvilken invistering skal ændres(id) --> ");
                var invisteringId = 0;
                int.TryParse(Console.ReadLine(), out invisteringId);
                if (invisteringId == 0) { await ThrowSleepyErrorAsyncInline($"{errTastTal}").ConfigureAwait(false); goto InvisteringerMainMenn; }
                bool wasFound = false;
                await foreach (var item in invisteringer)
                {
                    if (item.Id == invisteringId)
                    {
                        wasFound = true;
                    }
                }
                if (!wasFound) { await ThrowSleepyErrorAsyncInline(errInvesteringMissingId + " " + invisteringId).ConfigureAwait(false); goto InvisteringerMainMenn; }
                wasFound = false;
                Console.WriteLine("\n");
                Console.WriteLine("OBS! 0 er inkluderet");
                Console.Write("Hvor mange dage indtil den udløber? --> ");
                var invisterDage = 0;
                int.TryParse(Console.ReadLine(), out invisterDage);
                if (invisterDage == 0) { await ThrowWarningAsyncInline(warnInputZero).ConfigureAwait(false); }
                Console.Write("Hvor mange timer indtil den udløber? --> ");
                var invisterTimer = 0;
                int.TryParse(Console.ReadLine(), out invisterTimer);
                if (invisterTimer == 0) { await ThrowWarningAsyncInline(warnInputZero).ConfigureAwait(false); }
                Console.Write("Hvor mange minutter indtil den udløber? --> ");
                var invistermin = 0;
                int.TryParse(Console.ReadLine(), out invistermin);
                if (invistermin == 0) { await ThrowWarningAsyncInline(warnInputZero).ConfigureAwait(false); }
                bool wasSaved = false;
                await foreach (var item in invisteringer)
                {
                    if (item.Id == invisteringId)
                    {
                        await asyncDbTasks.SetExpireDatemanuallyInvistAsync(invisteringId, invisterDage, invisterTimer, invistermin).ConfigureAwait(false);
                        await ThrowSleepySuccessAsyncInline($"{item.Name} blev opdateret");
                        wasSaved = true;
                        break;
                    }
                }
                if (!wasSaved)
                {
                    await ThrowSleepyErrorAsyncInline($"{errInvesteringMissingId} {invisteringId}").ConfigureAwait(false);
                }

                goto InvisteringerMainMenn;
                #endregion
            }
        }
    }
    async Task DisplayKits()
    {

    displayKitsMenu:;
        using (var context = new DbService())
        {
            #region DisplayKitsOnInit
            Console.Clear();
            var activeKits = new List<string>();
            var activeKitsBp = new List<string>();
            var bpKits = asyncDbTasks.GetBpKitsStreamAsync().ConfigureAwait(false);
            var kitsDontExpire = asyncDbTasks.GetKitsAsync().ConfigureAwait(false);
            Console.WriteLine("-------- Kits -----------");
            #endregion

            #region DisplayKitsTemplate
            await foreach (var kit in kitsDontExpire)
            {
                if (kit.CanBeTaken < DateTime.Now)
                {
                    #region DisplayIfReady
                    Console.WriteLine("---------------------------------");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Kit:");
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($" {kit.Name}.");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Kit nummer: ");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"{kit.Id}");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Dette kit er klar!:D");
                    activeKits.Add(kit.Name);
                    Console.ForegroundColor = ConsoleColor.White;
                    #endregion
                }
                else
                {
                    #region DisplayIfNotReady
                    Console.WriteLine("---------------------------------");
                    Console.Write($"Kit:");
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($" {kit.Name}.");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"Kit nummer: ");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"{kit.Id}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"Kan tages om ");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"{kit.CanBeTaken - DateTime.Now}");
                    Console.ForegroundColor = ConsoleColor.White;
                    activeKits.Add(kit.Name);
                    #endregion
                }
            }

            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("-------- Bp Kits -----------");
            Console.WriteLine("Slettes automatisk når de udløber ( jear måske XD. Jeg satser/håber )");
            await foreach (var kit in bpKits)
            {

                var targetTime = kit.LastTaken.AddDays(1);
                var canBeTakenHours = targetTime - DateTime.Now;
                if (kit.ExpireDate < DateTime.Now) { context.BpKits.Remove(kit); await context.SaveChangesAsync().ConfigureAwait(false); }
                // is not refreshing the context 
                else if (targetTime < DateTime.Now)
                {
                    Console.WriteLine("---------------------------------");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Kit:");
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($" {kit.Name}.");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"Kit nummer: ");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"{kit.Id}");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($" Dette kit er klar!:D");
                    Console.Write("Udløber den:");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($" {kit.ExpireDate}");
                    activeKitsBp.Add(kit.Name);
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.WriteLine("---------------------------------");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"Kit:");
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($" {kit.Name}.");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"Kit nummer: ");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"{kit.Id}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"Kan tages om:");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($" {canBeTakenHours}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("Udløber den:");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($" {kit.ExpireDate}");
                    activeKitsBp.Add(kit.Name);
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            #endregion

            #region KitsOptions
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("--- Kit options ---");
            Console.WriteLine("1. Opret buy kit");
            Console.WriteLine("2. Opret BP kit");
            Console.WriteLine("3. Fjern kit(Rare usecase)");
            Console.WriteLine("4. Tag kit");
            Console.WriteLine("5. Set kit cooldown til et specifikt tidspukt");
            Console.WriteLine("x/Enter. Gå tilbage");
            Console.Write("--> ");
            var userinput2 = 0;
            int.TryParse(Console.ReadLine(), out userinput2);
            #endregion

            if (userinput2 == 1)
            {
                #region KitOptionAddKitBuy
                Console.WriteLine("\n");
                Console.WriteLine("-- Hvilket kit? --");
                string[] kitsString = new string[] { "Madchemist", "Legend", "Titan", "Op", "Konge", "Bf", "Key" };
                int kitNumber = 1;

                foreach (var kit in kitsString)
                {
                    if (activeKits.Contains(kit))
                    {
                        await ThrowErrorAsyncInline($"{kitNumber}. {kit}. {errKitAlreadyOwned}").ConfigureAwait(false);
                    }
                    else
                    {
                        Console.WriteLine($"{kitNumber}. {kit}");
                    }
                    kitNumber++;
                }
                Console.Write("--> ");
                var userInput3 = 0;
                int.TryParse(Console.ReadLine(), out userInput3);
                bool wasSaved = false;
                if (userInput3 == 0) { await ThrowSleepyErrorAsyncInline(errTastTal).ConfigureAwait(false); goto displayKitsMenu; }

                switch (userInput3)
                {
                    case 1:
                        #region Madchemist
                        if (activeKits.Contains("Madchemist"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errKitAlreadyOwned).ConfigureAwait(false);
                            goto displayKitsMenu;
                        }
                        else
                        {
                            // add kit 
                            var newKit = new KitNeverExpire { Name = "Madchemist", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(1) };
                            await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasSaved = true;
                        }
                        break;
                    #endregion
                    case 2:
                        #region Legend
                        if (activeKits.Contains("Legend"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errKitAlreadyOwned).ConfigureAwait(false);
                            goto displayKitsMenu;
                        }
                        else
                        {
                            // add kit 
                            var newKit = new KitNeverExpire { Name = "Legend", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(1) };
                            await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasSaved = true;
                        }
                        break;
                    #endregion
                    case 3:
                        #region Titan
                        if (activeKits.Contains("Titan"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errKitAlreadyOwned).ConfigureAwait(false);
                            goto displayKitsMenu;
                        }
                        else
                        {
                            var newKit = new KitNeverExpire { Name = "Titan", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(1) };
                            await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasSaved = true;
                        }
                        break;
                    #endregion
                    case 4:
                        #region Op 
                        if (activeKits.Contains("Op"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errKitAlreadyOwned).ConfigureAwait(false);
                            goto displayKitsMenu;
                        }
                        else
                        {
                            var newKit = new KitNeverExpire { Name = "Op", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(2) };
                            await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasSaved = true;
                        }
                        break;
                    #endregion
                    case 5:
                        #region Konge 
                        if (activeKits.Contains("Konge"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errKitAlreadyOwned).ConfigureAwait(false);
                            goto displayKitsMenu;
                        }
                        else
                        {
                            var newKit = new KitNeverExpire { Name = "Konge", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(2) };
                            await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasSaved = true;
                        }
                        break;
                    #endregion
                    case 6:
                        #region Bf
                        if (activeKits.Contains("Bf"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errKitAlreadyOwned).ConfigureAwait(false);
                            goto displayKitsMenu;
                        }
                        else
                        {
                            // add kit 
                            var newKit = new KitNeverExpire { Name = "Bf", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(2) };
                            await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasSaved = true;
                        }
                        break;
                    #endregion
                    case 7:
                        #region Key  
                        if (activeKits.Contains("Key"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errKitAlreadyOwned).ConfigureAwait(false);
                            goto displayKitsMenu;
                        }
                        else
                        {
                            var newKit = new KitNeverExpire { Name = "Key", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(4) };
                            await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasSaved = true;
                        }
                        break;
                        #endregion
                }


                if (!wasSaved)
                {
                    await ThrowSleepyErrorAsyncInline($"{errKitMissingId} {userInput3}").ConfigureAwait(false);
                }
                else if (wasSaved)
                {
                    await ThrowSleepySuccessAsyncInline(succKitAdded).ConfigureAwait(false);
                }
                wasSaved = false;

                goto displayKitsMenu;
                #endregion
            }

            if (userinput2 == 2)
            {
                #region KitOptionAddKitBp
                bool wasSaved = false;
                Console.WriteLine("\n");
                Console.WriteLine("-- Hvilket kit? --");

                string[] kitsBpString = new string[] { "Kit head", "Kit tools", "Kit dollar" };
                int kitBpNumber = 1;

                foreach (var kitBp in kitsBpString)
                {
                    if (activeKitsBp.Contains(kitBp))
                    {
                        await ThrowErrorAsyncInline($"{kitBpNumber}. {kitBp}. {errKitAlreadyOwned}").ConfigureAwait(false);
                    }
                    else
                    {
                        Console.WriteLine($"{kitBpNumber}. {kitBp}");
                    }
                    kitBpNumber++;
                }

                Console.Write("--> ");
                var userInput4 = 0;
                int.TryParse(Console.ReadLine(), out userInput4);
                if (userInput4 == 0) { await ThrowSleepyErrorAsyncInline(errTastTal).ConfigureAwait(false); goto displayKitsMenu; }

                switch (userInput4)
                {
                    case 1:
                        #region Kit head
                        if (activeKitsBp.Contains("Kit head"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errKitAlreadyOwned).ConfigureAwait(false);
                            goto displayKitsMenu;
                        }
                        else
                        {
                            var newKit = new BpKit { Name = "Kit head", LastTaken = DateTime.Now, ExpireDate = DateTime.Now.AddDays(7) };
                            context.BpKits.Add(newKit);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasSaved = true;
                        }
                        break;
                    #endregion
                    case 2:
                        #region Kit tools
                        if (activeKitsBp.Contains("Kit tools"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errKitAlreadyOwned).ConfigureAwait(false);
                            goto displayKitsMenu;
                        }
                        else
                        {
                            var newKit = new BpKit { Name = "Kit tools", LastTaken = DateTime.Now, ExpireDate = DateTime.Now.AddDays(7) };
                            context.BpKits.Add(newKit);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasSaved = true;
                        }
                        break;
                    #endregion
                    case 3:
                        #region Kit dollar
                        if (activeKitsBp.Contains("Kit dollar"))
                        {
                            Console.WriteLine("\n");
                            await ThrowSleepyErrorAsyncInline(errKitAlreadyOwned).ConfigureAwait(false);
                            goto displayKitsMenu;
                        }
                        else
                        {
                            var newKit = new BpKit { Name = "Kit dollar", LastTaken = DateTime.Now, ExpireDate = DateTime.Now.AddDays(7) };
                            context.BpKits.Add(newKit);
                            await context.SaveChangesAsync().ConfigureAwait(false);
                            wasSaved = true;
                        }
                        break;
                        #endregion
                }

                if (!wasSaved)
                {
                    await ThrowSleepyErrorAsyncInline($"{errKitMissingId} {userInput4}").ConfigureAwait(false);
                }
                else if (wasSaved)
                {
                    await ThrowSleepySuccessAsyncInline(succKitAdded).ConfigureAwait(false);
                }
                wasSaved = false;

                goto displayKitsMenu;
                #endregion
            }

            if (userinput2 == 3)
            {
                #region KitOptionRemoveKitRareUseCase
                Console.WriteLine("\n");
                Console.WriteLine("Hvilken kategorig vil du slette fra? kits: 1 / Bp kits: 2");
                Console.Write("--> ");
                var category = 0;
                int.TryParse(Console.ReadLine(), out category);
                if (category == 0) { await ThrowSleepyErrorAsyncInline(errTastTal).ConfigureAwait(false); goto displayKitsMenu; }
                if (category != 1 && category != 2)
                {
                    await ThrowSleepyErrorAsyncInline($"{errMissingCategory} {category}").ConfigureAwait(false);
                    goto displayKitsMenu;
                }
                Console.Write("Kit nummer --> ");

                var userInput5 = 0;
                int.TryParse(Console.ReadLine(), out userInput5);
                if (userInput5 == 0) { await ThrowSleepyErrorAsyncInline(errTastTal).ConfigureAwait(false); goto displayKitsMenu; }
                bool wasSaved = false;

                if (category == 1)
                {
                    await foreach (var kit in kitsDontExpire)
                    {
                        if (kit.Id == userInput5)
                        {
                            context.kitNeverExpires.Remove(kit);
                            wasSaved = true;
                        }
                    }
                    if (!wasSaved)
                    {
                        await ThrowSleepyErrorAsyncInline($"{errKitMissingId} {userInput5}").ConfigureAwait(false);
                    }
                    else if (wasSaved)
                    {
                        await ThrowSleepySuccessAsyncInline(succKitRemoved).ConfigureAwait(false);
                    }
                    wasSaved = false;

                }

                if (category == 2)
                {
                    await foreach (var kit in bpKits)
                    {
                        if (kit.Id == userInput5)
                        {
                            context.BpKits.Remove(kit);
                            wasSaved = true;
                        }
                    }
                    if (!wasSaved)
                    {
                        await ThrowSleepyErrorAsyncInline($"{errKitMissingId} {userInput5}").ConfigureAwait(false);
                    }
                    else if (wasSaved)
                    {
                        await ThrowSleepySuccessAsyncInline(succKitRemoved).ConfigureAwait(false);
                    }
                    wasSaved = false;
                }


                await context.SaveChangesAsync().ConfigureAwait(false);

                goto displayKitsMenu;
                #endregion
            }

            if (userinput2 == 4)
            {
                #region KitOptionTakeKit

                Console.WriteLine("\n");
                Console.WriteLine("Hvilken kategorig vil du tage fra? kits: 1 / Bp kits: 2");
                Console.Write("--> ");
                var category = 0;
                int.TryParse(Console.ReadLine(), out category);
                if (category == 0) { await ThrowSleepyErrorAsyncInline($"{errTastTal}").ConfigureAwait(false); goto displayKitsMenu; }
                if (category != 1 && category != 2)
                {
                    await ThrowSleepyErrorAsyncInline($"{errMissingCategory} {category}").ConfigureAwait(false);
                    goto displayKitsMenu;
                }
            Repeat:;
                Console.WriteLine("f. færdig");
                Console.Write("Kit nummer --> ");
                var userInput6 = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(userInput6)) { await ThrowErrorAsyncInline(errNumberOfF).ConfigureAwait(false); goto Repeat; }
                if (userInput6 == "f") { Console.Clear(); goto displayKitsMenu; }
                else
                {
                    if (!int.TryParse(userInput6, out int userInputToInt))
                    {
                        await ThrowErrorAsyncInline($"{errNumberOfF}").ConfigureAwait(false);
                        goto Repeat;
                    }

                    bool wasSaved = false;

                    if (category == 1)
                    {
                        await foreach (var kit in kitsDontExpire)
                        {
                            if (kit.Id == userInputToInt)
                            {
                                await asyncDbTasks.SaveNEKitAsync(kit).ConfigureAwait(false);
                                wasSaved = true;
                                await ThrowSleepySuccessAsyncInline(succKitTaget).ConfigureAwait(false);
                            }
                        }

                        if (!wasSaved)
                        {
                            await ThrowErrorAsyncInline($"{errKitMissingId} {userInput6}").ConfigureAwait(false);
                        }
                        wasSaved = false;
                    }
                    if (category == 2)
                    {
                        await foreach (var kit in bpKits)
                        {
                            if (kit.Id == userInputToInt)
                            {
                                await asyncDbTasks.SaveBpKitAsync(kit).ConfigureAwait(false);
                                wasSaved = true;
                                await ThrowSleepySuccessAsyncInline(succKitTaget).ConfigureAwait(false);
                            }
                        }

                        if (!wasSaved)
                        {
                            await ThrowErrorAsyncInline($"{errKitMissingId}  {userInput6}").ConfigureAwait(false);
                        }
                        wasSaved = false;
                    }

                    goto Repeat;
                }
                #endregion
            }

            if (userinput2 == 5)
            {
                #region KitOptionChangeKit
                Console.WriteLine("-- Vælg kategori --");
                Console.WriteLine("1. Buy kits");
                Console.WriteLine("2. Bp kits");
                Console.Write("Vælg kategori --> ");
                var userInput13 = 0;
                int.TryParse(Console.ReadLine(), out userInput13);
                if (userInput13 == 0) { await ThrowSleepyErrorAsyncInline(errTastTal).ConfigureAwait(false); goto displayKitsMenu; }
                if (userInput13 != 1 && userInput13 != 2) { await ThrowSleepyErrorAsyncInline(errMissingCategory + " " + userInput13).ConfigureAwait(false); goto displayKitsMenu; }
                Console.Write("Hvilket kit vil du ændre? Kit nummer --> ");
                var userInput12 = 0;
                int.TryParse(Console.ReadLine(), out userInput12);
                if (userInput12 == 0) { await ThrowSleepyErrorAsyncInline(errTastTal).ConfigureAwait(false); goto displayKitsMenu; }                                         // og matcher med et kit i lsiten?  via was Saved in loop
                if (userInput12 != 1 && userInput12 != 2) { await ThrowSleepyErrorAsyncInline(errMissingCategory + " " + userInput12).ConfigureAwait(false); goto displayKitsMenu; }
                bool wasSaved = false;
                if (userInput13 == 1)
                {
                    Console.WriteLine("\n");
                    Console.WriteLine("OBS! 0 er inkluderet");
                    Console.Write("Hvor mange dage er der, indtil du kan tage det igen? --> ");
                    var kitDage = 0;
                    int.TryParse(Console.ReadLine(), out kitDage);
                    if (kitDage == 0) { await ThrowWarningAsyncInline(warnInputZero).ConfigureAwait(false); }
                    Console.Write("Hvor mange timer, indtil du kan tage det igen? --> ");
                    var kitTimer = 0;
                    int.TryParse(Console.ReadLine(), out kitTimer);
                    if (kitTimer == 0) { await ThrowWarningAsyncInline(warnInputZero).ConfigureAwait(false); }
                    Console.Write("Hvor mange minutter, indtil du kan tage det igen? --> ");
                    var kitMin = 0;
                    int.TryParse(Console.ReadLine(), out kitMin);
                    if (kitMin == 0) { await ThrowWarningAsyncInline(warnInputZero).ConfigureAwait(false); }
                    await foreach (var item in kitsDontExpire)
                    {
                        if (item.Id == userInput12)
                        {
                            await asyncDbTasks.SetExpireDatemanuallyKitNEAsync(item.Id, kitDage, kitTimer, kitMin).ConfigureAwait(false);
                            wasSaved = true;
                        }
                    }
                    if (wasSaved)
                    {
                        await ThrowSleepySuccessAsyncInline(succKitChanged).ConfigureAwait(false);
                    }
                    wasSaved = false;
                }
                if (userInput13 == 2)
                {
                    Console.WriteLine("\n");
                    wasSaved = false;
                    Console.WriteLine("OBS! 0 er inkluderet");
                    Console.Write("Hvor mange timer, indtil du kan tage det igen? --> ");
                    var invisterTimer = 0;
                    int.TryParse(Console.ReadLine(), out invisterTimer);
                    if (invisterTimer == 0) { await ThrowWarningAsyncInline(warnInputZero).ConfigureAwait(false); }
                    Console.Write("Hvor mange minutter, indtil du kan tage det igen? --> ");
                    var invistermin = 0;
                    int.TryParse(Console.ReadLine(), out invistermin);
                    if (invistermin == 0) { await ThrowWarningAsyncInline(warnInputZero).ConfigureAwait(false); }

                    await foreach (var item in bpKits)
                    {
                        if (item.Id == userInput12)
                        {
                            await asyncDbTasks.SetExpireDatemanuallyBPKitasync(item.Id, invisterTimer, invistermin).ConfigureAwait(false);
                            wasSaved = true;
                        }
                    }
                    if (wasSaved)
                    {
                        await ThrowSleepySuccessAsyncInline(succKitChanged).ConfigureAwait(false);
                    }
                    wasSaved = false;
                }
                goto displayKitsMenu;
                #endregion
            }
        }

    }
    async Task DisplaySettings()
    {
    DisplaySettingsMainMenu:;
        
        #region ChangeableSettings
        Console.Clear();
        Console.WriteLine("--- Setting ---");
        Console.WriteLine($"1. Error message display time(Default:1000ms) || Current value: {settings.ErrorMessageDisplayTime}");
        Console.WriteLine($"2. Success message display time(Default:300ms) || Current value: {settings.SuccessMessageDisplayTime}");
        Console.WriteLine("X/Enter. Gå tilbage");
        Console.Write("Change --> ");
        
        int userInput11 = 0;
        int.TryParse(Console.ReadLine(), out userInput11);
        if (userInput11 == 0) { goto Leave; }
        if (userInput11 != 1 && userInput11 != 2) { await ThrowSleepyErrorAsyncInline(errSettingsNoMatchId + " " + userInput11); goto DisplaySettingsMainMenu; }
        bool wasSaved = false;
        #endregion

        if (userInput11 == 1)
        {
            #region SettingChangeOption1
            Console.Write("Hvad skal den nye værdi være?(Indtast i millisekunder) --> ");
            var userInputNewErrorMessageDisplayTimeValue = 0;
            int.TryParse(Console.ReadLine(), out userInputNewErrorMessageDisplayTimeValue);
            if (userInputNewErrorMessageDisplayTimeValue == 0) { await ThrowSleepyErrorAsyncInline(errTastTal).ConfigureAwait(false); goto DisplaySettingsMainMenu; }
            await asyncDbTasks.SaveSettings(userInputNewErrorMessageDisplayTimeValue, settings.SuccessMessageDisplayTime).ConfigureAwait(false);
            wasSaved = true;
            #endregion
        }

        if (userInput11 == 2)
        {
            #region SettingChangeOption2
            Console.Write("Hvad skal den nye værdi være?(Indtast i millisekunder) --> ");
            var userInputSuccessMessageDisplayTimeValue = 0;
            int.TryParse(Console.ReadLine(), out userInputSuccessMessageDisplayTimeValue);
            if (userInputSuccessMessageDisplayTimeValue == 0) { await ThrowSleepyErrorAsyncInline(errTastTal).ConfigureAwait(false); goto DisplaySettingsMainMenu; }
            await asyncDbTasks.SaveSettings(settings.ErrorMessageDisplayTime, userInputSuccessMessageDisplayTimeValue).ConfigureAwait(false);
            wasSaved = true;
            #endregion
        }

        if (wasSaved)
        {
            await ThrowSleepySuccessAsyncInline(succSettingsSavedChanged).ConfigureAwait(false); wasSaved = false;
            using (var context = new DbService())
            {
                settings = await context.Settings.FirstOrDefaultAsync().ConfigureAwait(false);
            }
            goto DisplaySettingsMainMenu;
        }
    Leave:;

    }


    async Task ThrowWarningAsyncInline(string message)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(message);
        Console.ForegroundColor = ConsoleColor.White;
    }
    async Task ThrowErrorAsyncInline(string message)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(message);
        Console.ForegroundColor = ConsoleColor.White;
    }
    async Task ThrowSleepyErrorAsyncInline(string message)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(message);
        Console.ForegroundColor = ConsoleColor.White;
        Thread.Sleep(settings.ErrorMessageDisplayTime); // Thread.Sleep inside a task? Good idea?
    }
    async Task ThrowSleepySuccessAsyncInline(string message)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(message);
        Console.ForegroundColor = ConsoleColor.White;
        Thread.Sleep(settings.SuccessMessageDisplayTime); // Thread.Sleep inside a task? Good idea?
    }

}
catch (Exception ex)
{
    LogError(ex);
loggerforce:;
    Console.WriteLine("!Caught unhandled exception. Please contact the dev.");
    Console.ReadLine();
    goto loggerforce;
}

static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
{
    LogError((Exception)e.ExceptionObject);
    Console.WriteLine("An error occurred. Please contact the dev.");
    Console.ReadLine();
}
static void TaskScheduler_UnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs e)
{
    LogError(e.Exception);
    Console.WriteLine("An error occurred. Please contact the dev.");
    e.SetObserved();
    Console.ReadLine();
}
static void LogError(Exception ex)
{
    File.AppendAllText("errorLog.txt", $"{DateTime.Now} - {ex.ToString()}\n");
}

