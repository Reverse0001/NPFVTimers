﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rapp.Models
{
    public class Invistering
    {
        public int Id { get; set; }
        public string Name { get; set; }
       // public int ExpiresIn { get; set; }
        //public DateTime ExpireDateDate { get; set; }
        //public TimeSpan ExpireDateTime { get; set; }
        public DateTime ExpireDate { get; set; }   // <-- Property is never used 
        public DateTime LastTakenDate { get; set; }  
        //public TimeSpan LastTakenTime { get; set; }
    }
}
