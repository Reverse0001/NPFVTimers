﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Tokens;
using Rapp.Models;
using Rapp.Services;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Xml;


#region OnInit
var userInput = 0;
var asyncDbTasks = new AsyncDbTasks();
#endregion

while (true)
{

    await DisplayMainMenu().ConfigureAwait(false);
    int.TryParse(Console.ReadLine(), out userInput);


    if (userInput == 1)    
    {
        await DisplayGrundeMenu().ConfigureAwait(false);
    }
    else if (userInput == 2)
    {
        await DisplayInvisteringer().ConfigureAwait(false); 
    }
    else if (userInput == 3)
    {
        await DisplayKits().ConfigureAwait(false);
    }
    Console.Clear();
}


// taking stuff that is stil on cooldown confirmation? 
// Ikke sure fjern kit works

async Task DisplayMainMenu()
{
    Console.WriteLine("FV Dashboard");
    Console.WriteLine("\n");
    Console.WriteLine("--- Options ---");
    Console.WriteLine("1. Grunde.");
    Console.WriteLine("2. Investeringer.");
    Console.WriteLine("3. Kits.");
    Console.Write("--> ");
}

async Task DisplayGrundeMenu()
{
    Console.Clear();
    grundeLabel:;

    using (var context = new DbService())
    {
        var grunde = asyncDbTasks.GetGrundeAsync().ConfigureAwait(false);
        Console.WriteLine("     --- Dine Grunde ---");
        await foreach (var grund in grunde)
        {
            #region DisplayGrundTemplate
            var dagee2 = grund.LastTimeDaysWereAddedDate + TimeSpan.FromDays(9);
            var tilbage = (dagee2 - DateTime.Now).TotalDays;
            Console.WriteLine("---------------------------------");
            Console.WriteLine($"Navn: {grund.Name}.");
            Console.WriteLine($"Udløber den: {dagee2}(Tidligst)");
            Console.WriteLine($"Udløber om: {tilbage}, dage(Tidligst)");
            if (tilbage <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart. Add dage."); goto skipState; }
            if (tilbage <= 7) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Kunne være du skulle overveje at adde dage"); goto skipState; }
            if (tilbage <= 10) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer for at den udløber"); goto skipState; }
        skipState:;
            Console.ForegroundColor = ConsoleColor.White;
            #endregion
        }

        #region GrundeOptions
        Console.WriteLine("---------------------------------");
        Console.WriteLine("\n");
        Console.WriteLine("--- Options ---");
        Console.WriteLine("1. Add Grund");
        Console.WriteLine("2. Del Grund");
        Console.WriteLine("3. AddDays Grund");
        Console.WriteLine("X/Enter. Gå tilbage");
        Console.Write("--> ");
        var userInput2 = 0;
        #endregion

        int.TryParse(Console.ReadLine(), out userInput2);
        if (userInput2 == 1)
        {
            #region GrundOptionAddGrund
            tryagain:;
            Console.WriteLine("Fortryd?: f");
            Console.Write("Grund Navn --> ");
            var grundNavn = Console.ReadLine();
            if (grundNavn == "f") { Console.Clear(); goto grundeLabel; }
            else
            {
                if (String.IsNullOrWhiteSpace(grundNavn)) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("Din grund skal have et navn"); Console.ForegroundColor = ConsoleColor.White; goto tryagain; }
                await foreach (var grund in grunde)
                {
                    if (grund.Name == grundNavn) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("Dine grunde skal have unikke navne"); Console.ForegroundColor = ConsoleColor.White; goto tryagain; }
                }
                var grundSomAddes = new Grund()
                {
                    Name = grundNavn,
                    LastTimeDaysWereAddedDate = DateTime.Now,
                };

                await context.Grunde.AddAsync(grundSomAddes).ConfigureAwait(false);
                await context.SaveChangesAsync().ConfigureAwait(false);
                Console.Clear();
                goto grundeLabel;
            }
            #endregion
        }

        if (userInput2 == 2)
        {
            #region GrundOptionRemoveGrund

            delgrundretry:;
            bool wasDeleted = false;
            Console.WriteLine("Fortryd?: f");
            Console.Write("Slet grund med navnet --> ");
            var grundToDelete = Console.ReadLine();
            if (grundToDelete == "f") { Console.Clear(); goto grundeLabel; }
            else
            {
                if (String.IsNullOrWhiteSpace(grundToDelete)) { Console.ForegroundColor = ConsoleColor.Red;  Console.WriteLine("Invalid grund navn"); Console.ForegroundColor = ConsoleColor.White; goto delgrundretry; }
                await foreach (var grund in grunde)
                {
                    if (grund.Name == grundToDelete)
                    {
                        context.Remove(grund);
                        wasDeleted = true;
                    }
                }
                await context.SaveChangesAsync().ConfigureAwait(false);
                if (wasDeleted == false) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine($"Kunne ikke finde en grund med navnet {grundToDelete}"); Console.ForegroundColor = ConsoleColor.White;  goto delgrundretry; }
                Console.Clear();
                goto grundeLabel;

            }
            #endregion
        }

      
            #region GrundOptionAddDays

        if (userInput2 == 3)
            {
            retryyy:;
            Console.WriteLine("Fortryd?: f");
            Console.Write("Hvilken grund(navn)? --> ");
            var grundNavn = Console.ReadLine();
            if (grundNavn == "f")
            {
                Console.Clear();
                goto grundeLabel;
            }
            else
            {
                if (String.IsNullOrWhiteSpace(grundNavn)) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("Invalid grund navn"); Console.ForegroundColor = ConsoleColor.White; goto retryyy; }
                var grundDerSkalOpdateres = await asyncDbTasks.GetSingleGrundAsync(grundNavn);
                if (grundDerSkalOpdateres == null) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine($"Kunne ikke finde en grund med navnet {grundNavn}"); Console.ForegroundColor = ConsoleColor.White; goto retryyy; }
                Console.WriteLine("1. Add max dage");
                Console.WriteLine("2. Set specifik tid // Ikke lavet endnu");
                Console.WriteLine("9. Fortryd");
            retry:;
                Console.Write("--> ");
                var userInput3 = 0;
                int.TryParse(Console.ReadLine(), out userInput3);

                if (userInput3 != 1 && userInput3 != 2 && userInput3 != 9)
                {
                    await ThrowErrorAsyncInline($"Invalid input: {userInput3}");
                    //Console.WriteLine("Invalid input");
                    goto retry;
                }
                if (userInput3 == 9)
                {
                    Console.Clear();
                    goto grundeLabel;
                }
                if (userInput3 == 1)
                {
                    // add 9 dage sidne du ikke kan maxe ud til 10. du har altid 9 dage og x timer
                    await asyncDbTasks.SaveGrundAsync(DateTime.Now, grundDerSkalOpdateres).ConfigureAwait(false);
                }
                else if (userInput3 == 2)
                {
                    var setDays = 9;
                    Console.Write("Sæt dage til --> ");
                    int.TryParse(Console.ReadLine(), out setDays);

                    var setHours = 24;
                    Console.Write("Sæt timer til --> ");
                    int.TryParse(Console.ReadLine(), out setHours);
                    // validate
                    await asyncDbTasks.SetExpireDateManuallyAsync(grundDerSkalOpdateres.Name, setDays, setHours).ConfigureAwait(false);


                    // Specifik dage set 
                    // ikke lavet endnu
                }
                Console.Clear();
                goto grundeLabel;
            }
        
            }
            #endregion
       

        Console.Clear();  // Clear on useless input 
    }
}
// Set udloobsdato til specefik tidsinterval


async Task DisplayInvisteringer()
{
    Console.Clear();
    using (var context = new DbService())
    {                      // hvis noget som helst er klart til at blive taget. skal der laves om paa hvad der bliver vist og farverne skla laves om 

        var invisteringer = asyncDbTasks.GetInvisteringerAsync().ConfigureAwait(false);
    invisteringer:;

        Console.WriteLine("  --- Dine Invisteringer ---");

        await foreach (var invist in invisteringer)
        {
            #region DisplayInvisteringerTemplate

            DateTime Udlllob = invist.LastTakenDate.AddDays(10);
            DateTime targetTime = invist.LastTakenDate.AddHours(24);
            TimeSpan kanTagesOm = targetTime - DateTime.Now;
            var udlooberOm = (Udlllob - DateTime.Now).TotalDays;
            if (targetTime < DateTime.Now)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("---------------------------------");
                Console.WriteLine($"Invisterings navn: {invist.Name}");
                Console.WriteLine($"Denne invistering er klar!:D");
                //Console.WriteLine($"Kan tages om: {kanTagesOm}, Timer/Min/Sek");
                Console.WriteLine($"Udløber om: {udlooberOm}, Dage");
                Console.WriteLine($"Udløber den: {invist.LastTakenDate.AddDays(10)}");
                if (udlooberOm <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart"); goto skipState; }
                if (udlooberOm <= 7) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Burde måske tage den snart"); goto skipState; }
                if (udlooberOm <= 11) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer"); goto skipState; }
            skipState:;
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {

                Console.WriteLine("---------------------------------");
                Console.WriteLine($"Invisterings navn: {invist.Name}");
                Console.WriteLine($"Kan tages om: {kanTagesOm}, Timer/Min/Sek");
                Console.WriteLine($"Udløber om: {udlooberOm}, Dage");
                Console.WriteLine($"Udløber den: {invist.LastTakenDate.AddDays(10)}");
                if (udlooberOm <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart"); goto skipState; }
                if (udlooberOm <= 7) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Burde måske tage den snart"); goto skipState; }
                if (udlooberOm <= 11) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer"); goto skipState; }
            skipState:;
                Console.ForegroundColor = ConsoleColor.Green;
            }
            #endregion
        }

        #region InvisteringerOptions
        Console.WriteLine("---------------------------------");
        Console.WriteLine("\n");
        Console.WriteLine("--- Options ---");
        Console.WriteLine("1. Opret Invistering");
        Console.WriteLine("2. Slet Invisterings");
        Console.WriteLine("3. Tag Invistering");
        Console.WriteLine("4. Sæt Invisterings timer manuelt");
        Console.WriteLine("x/Enter. Gå tilbage");
        Console.Write("--> ");
        var userInput5 = 0;
        #endregion

        int.TryParse(Console.ReadLine(), out userInput5);
     
        if (userInput5 == 1)
        {
            #region InvisteringOptionAddInvistering

            invisretry:;
            Console.WriteLine("f. Fortryd");
            Console.Write("Invisterings navn? --> ");
            var invisteringNavn = Console.ReadLine();
            //VAlidate inpt  // unikt navn 
            if (invisteringNavn == "f") { Console.Clear(); goto invisteringer; }
            if (String.IsNullOrWhiteSpace(invisteringNavn)) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("Invalid invisterings navn"); Console.ForegroundColor = ConsoleColor.White; goto invisretry; }
            await foreach (var inv in invisteringer) { if (inv.Name == invisteringNavn) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("Dine invisteringer skal have unikke navne"); Console.ForegroundColor = ConsoleColor.White; goto invisretry; } }
            var newInvistering = new Invistering { LastTakenDate = DateTime.Now, Name = invisteringNavn };
            await context.Invisteringer.AddAsync(newInvistering).ConfigureAwait(false);
            await context.SaveChangesAsync().ConfigureAwait(false);
            Console.Clear();
            goto invisteringer;
            #endregion
        }
        if (userInput5 == 2)
        {
            #region InvisteringOptionRemoveInvistering

            retry:;
            Console.WriteLine("f. Fortryd");
            Console.Write("Hvilken invistering skal slettes?(Navn) --> ");
            var invisteringToDelName = Console.ReadLine(); // validate
            if (invisteringToDelName == "f") { Console.Clear(); goto invisteringer; }
            if (String.IsNullOrWhiteSpace(invisteringToDelName)) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("Invalid invisterings navn"); Console.ForegroundColor = ConsoleColor.White; goto retry; }
            var invisteringToDelNameFromDb = await asyncDbTasks.GetSingleInvesteringAsync(invisteringToDelName);
            if (invisteringToDelNameFromDb == null) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine($"Kunne ikke finde en invistering med navnet {invisteringToDelName}"); Console.ForegroundColor = ConsoleColor.White; goto retry; }
            context.Invisteringer.Remove(invisteringToDelNameFromDb);
            await context.SaveChangesAsync().ConfigureAwait(false);
            Console.Clear();
            goto invisteringer;
            #endregion
        }
        if (userInput5 == 3)
        {
            #region InvisteringOptionResetTimer

            retry3:;
            Console.WriteLine("f. Fortryd");
            Console.Write("Hvilken invistering skal tages?(Navn) --> ");
            var invisteringToReset = Console.ReadLine(); // validate

            if (invisteringToReset == "f") { Console.Clear(); goto invisteringer; }
            if (String.IsNullOrWhiteSpace(invisteringToReset)) { Console.ForegroundColor = ConsoleColor.Red;  Console.WriteLine("Invalid invisterings navn"); Console.ForegroundColor = ConsoleColor.White; goto retry3; }
            var invisteringFromDb = await asyncDbTasks.GetSingleInvesteringAsync(invisteringToReset);
            if (invisteringFromDb == null) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine($"Kunne ikke finde en Invistering med navnet {invisteringToReset}"); Console.ForegroundColor = ConsoleColor.White; goto retry3; }
            
            await asyncDbTasks.SaveInvisteringAsync(invisteringFromDb).ConfigureAwait(false);
            Console.Clear();
            goto invisteringer;
            #endregion
        }
        if(userInput5 == 4)
        {
            // set timer
            Console.Write("hvilken invistering skal ændres(navn) --> ");
            var invisterName = Console.ReadLine();  // VALIDATE YET ÀGAIN IMMA KILL MYSELf

            Console.Write("Hvor mange dage er det tilbage lige nu? --> ");
            var invisterDage = 0;
            int.TryParse(Console.ReadLine(), out invisterDage); 
            //var invisterDage = Console.ReadLine();  // VALIDATE YET ÀGAIN IMMA KILL MYSELf
            // validate 
            await asyncDbTasks.SetExpireDatemanuallyInvistAsync(invisterName,invisterDage).ConfigureAwait(false);
            Console.Clear();
            goto invisteringer;

        }

        Console.Clear(); // Clear on useless input
    }
}

async Task DisplayKits()
{
    Console.Clear();
    displayKitsMenu:;
    var activeKits = new List<string>();
    var activeKitsBp = new List<string>();
    using (var context = new DbService())
    {
        var bpKits = asyncDbTasks.GetBpKitsAsync().ConfigureAwait(false);
        var kitsDontExpire = asyncDbTasks.GetKitsAsync().ConfigureAwait(false);

        Console.WriteLine("-------- Kits -----------"); 
        await foreach (var kit in kitsDontExpire)
        {
            if(kit.CanBeTaken < DateTime.Now)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("---------------------------------");
                Console.Write($"Kit: Kit {kit.Name}.");
                Console.WriteLine($" Dette kit er klar!:D");
                activeKits.Add(kit.Name);
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.WriteLine("---------------------------------");
                Console.Write($"Kit: Kit {kit.Name}");
                Console.WriteLine($" Kan tages om {kit.CanBeTaken - DateTime.Now}");
                activeKits.Add(kit.Name);
            }
        }

        Console.WriteLine("---------------------------------");
        Console.WriteLine("\n");
        Console.WriteLine("-------- Bp Kits -----------");
        Console.WriteLine("Slettes automatisk når de udløber ( jear måske XD. Jeg satser/håber )");
        await foreach (var kit in bpKits)
        {
            
            var targetTime = kit.LastTaken.AddDays(1);
            var canBeTakenHours = targetTime - DateTime.Now;
            if(kit.ExpireDate < DateTime.Now) { context.BpKits.Remove(kit); await context.SaveChangesAsync().ConfigureAwait(false);  } // maybe somehow break the loop

            else if (targetTime < DateTime.Now)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("---------------------------------");
                Console.Write($"Kit: {kit.Name}.");
                Console.WriteLine($" Dette kit er klar!:D");
                Console.WriteLine($"Udløber den: {kit.ExpireDate}");
                activeKitsBp.Add(kit.Name);
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.WriteLine("---------------------------------");
                Console.Write($"Kit: {kit.Name}.");
                Console.WriteLine($" Kan tages om: {canBeTakenHours}");
                Console.WriteLine($"Udløber den: {kit.ExpireDate}");
                activeKitsBp.Add(kit.Name);
            }
        }

        Console.WriteLine("---------------------------------");
        Console.WriteLine("\n");
        Console.WriteLine("--- Kit options ---");
        Console.WriteLine("1. Opret buy kit");
        Console.WriteLine("2. Opret BP kit");
        Console.WriteLine("3. Fjern kit(Rare usecase)");
        Console.WriteLine("4. Tag kit");
        Console.WriteLine("x/Enter. Gå tilbage");
        Console.Write("--> ");
        var userinput2 = 0;
        int.TryParse(Console.ReadLine(), out userinput2);
       
        if(userinput2 == 1)  // use case 
        {
            Console.WriteLine("\n");
            Console.WriteLine("-- Hvilket kit? --");
            if(activeKits.Contains("Madchemist"))
            {
                await ThrowErrorAsyncInline("1. Madchemist, (Det har du allerade)").ConfigureAwait(false);
            }
            else
            {
                Console.WriteLine("1. Madchemist");
            }

            if (activeKits.Contains("Legend"))
            {
                await ThrowErrorAsyncInline("2. Legend, (Det har du allerade)").ConfigureAwait(false);
                //// skift farve 
                //Console.ForegroundColor = ConsoleColor.Red;
                //Console.WriteLine("2. Leg, (Det har du allerade)");
                //Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.WriteLine("2. Legend");
            }

            if (activeKits.Contains("Titan"))
            {
                await ThrowErrorAsyncInline("3. Titan, (Det har du allerade)").ConfigureAwait(false);
                //Console.ForegroundColor = ConsoleColor.Red;
                //Console.WriteLine("3. Tit, (Det har du allerade)");
                //Console.ForegroundColor = ConsoleColor.White;

            }
            else
            {
                Console.WriteLine("3. Titan");
            }

            if (activeKits.Contains("Op"))
            {
                // skift farve 
                await ThrowErrorAsyncInline("4. Op, (Det har du allerade)").ConfigureAwait(false);
                //Console.ForegroundColor = ConsoleColor.Red;
                //Console.WriteLine("4. Op, (Det har du allerade)");
                //Console.ForegroundColor = ConsoleColor.White;

            }
            else
            {
                Console.WriteLine("4. Op");
            }

            if (activeKits.Contains("Konge"))
            {
                await ThrowErrorAsyncInline("5. Konge, (Det har du allerade)").ConfigureAwait(false);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("5. Konge, (Det har du allerade)");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else
            {
                Console.WriteLine("5. Konge");
            }

            if (activeKits.Contains("Bf"))
            {
                // skift farve 
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("6. Bf, (Det har du allerade)");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else
            {
                Console.WriteLine("6. Bf");
            }

            if (activeKits.Contains("Key"))
            {
                // skift farve 
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("7. Key, (Det har du allerade)");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else
            {
                Console.WriteLine("7. Key");
            }


            Console.WriteLine("x/Enter. Gå tilbage");
        retry:;
            Console.Write("--> ");
            var userInput3 = 0;
            int.TryParse(Console.ReadLine(), out userInput3);
           
            if(userInput3 == 1)
            {
                if(activeKits.Contains("Madchemist")) 
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Du har allerade kit Madchemist");
                    goto retry;
                }
                else
                {
                    // add kit 
                    var newKit = new KitNeverExpire { Name = "Madchemist", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(1) };
                    await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            if (userInput3 == 2)
            {
                if (activeKits.Contains("Legend"))
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Du har allerade kit Legend");
                    goto retry;
                }
                else
                {
                    // add kit 
                    var newKit = new KitNeverExpire { Name = "Legend", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(1) };
                    await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            if (userInput3 == 3)
            {
                if (activeKits.Contains("Titan"))
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Du har allerade kit Titan");
                    goto retry;
                }
                else
                {
                    // add kit 
                    var newKit = new KitNeverExpire { Name = "Titan", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(1) };
                    await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            if(userInput3 == 4)
            {
                if (activeKits.Contains("Op"))
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Du har allerade kit Op");
                    goto retry;
                }
                else
                {
                    // add kit 
                    var newKit = new KitNeverExpire { Name = "Op", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(2) };
                    await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            if(userInput3 == 5)
            {
                if (activeKits.Contains("Konge"))
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Du har allerade kit Konge");
                    goto retry;
                }
                else
                {
                    // add kit 
                    var newKit = new KitNeverExpire { Name = "Konge", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(2) };
                    await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            if (userInput3 == 6)
            {
                if (activeKits.Contains("Bf"))
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Du har allerade kit Bf");
                    goto retry;
                }
                else
                {
                    // add kit 
                    var newKit = new KitNeverExpire { Name = "Bf", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(2) };
                    await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            if (userInput3 == 7)
            {
                if (activeKits.Contains("Key"))
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Du har allerade kit Key");
                    goto retry;
                }
                else
                {
                    // add kit 
                    var newKit = new KitNeverExpire { Name = "Key", LastTaken = DateTime.Now, CanBeTaken = DateTime.Now.AddDays(4) };
                    await context.kitNeverExpires.AddAsync(newKit).ConfigureAwait(false);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            Console.Clear();
            goto displayKitsMenu;
        }


        // opret bp kit
        if(userinput2 == 2)
        {


            Console.WriteLine("\n");
            Console.WriteLine("-- Hvilket kit? --");
            if(activeKitsBp.Contains("Kit head"))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("1. Kit head(Det har du allerade)");
                Console.ForegroundColor= ConsoleColor.White;
            }
            else
            {
                Console.WriteLine("1. Kit head");
            }


            if (activeKitsBp.Contains("Kit tools"))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("2. Kit tools(Det har du allerade)");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.WriteLine("2. Kit tools");
            }


            if (activeKitsBp.Contains("Kit dollar"))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("3. Kit dollar(Det har du allerade)");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.WriteLine("3. Kit dollar");
            }




            Console.WriteLine("x/Enter. Gå tilbage");
        retry:;
            Console.Write("--> ");
            var userInput4 = 0;
            int.TryParse(Console.ReadLine(), out userInput4);

            if(userInput4 == 1)
            {
                if(activeKitsBp.Contains("Kit head"))
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Du har allerade kit head");
                    goto retry;
                }
                else
                {
                    var newKit = new BpKit { Name = "Kit head", LastTaken = DateTime.Now, ExpireDate = DateTime.Now.AddDays(7) };
                    context.BpKits.Add(newKit);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            if(userInput4 == 2)
            {
                if(activeKitsBp.Contains("Kit tools"))
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Du har allerade kit tools");
                    goto retry;
                }
                else
                {
                    var newKit = new BpKit { Name = "Kit tools", LastTaken = DateTime.Now, ExpireDate = DateTime.Now.AddDays(7) };
                    context.BpKits.Add(newKit);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            if(userInput4 == 3)
            {
                if(activeKitsBp.Contains("Kit dollar"))
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Du har allerade kit dollar");
                    goto retry;
                }
                else
                {
                    var newKit = new BpKit { Name = "Kit dollar", LastTaken = DateTime.Now, ExpireDate = DateTime.Now.AddDays(7) };
                    context.BpKits.Add(newKit);
                    await context.SaveChangesAsync().ConfigureAwait(false);
                }
            }

            //await context.SaveChangesAsync().ConfigureAwait(false); // Needed?
            Console.Clear();
            goto displayKitsMenu;
        }




      //  s kan fjjerne kits forbegge caretories 
        // fjern kit        Lav op i forhold til at duog
        //remove kits also needs categories for removal of a kit 
        if(userinput2 == 3) 
        {
            Console.WriteLine("\n");
            Console.WriteLine("-- Kits --");
            await foreach (var kit in kitsDontExpire)
            {
                Console.WriteLine(kit.Id + ". " + kit.Name);
            }
            Console.WriteLine("\n");
            Console.WriteLine("-- Bp Kits --");
            await foreach (var kit in bpKits)
            {
                Console.WriteLine(kit.Id + ". " + kit.Name);
            }
            Console.WriteLine("\n");
            Console.WriteLine("Hvilken kategorig vil du slette fra? kits: 1 / Bp kits: 2");
            Console.Write("--> ");
            var category = 0;
            int.TryParse(Console.ReadLine(), out category);
            //validate input 
            Console.Write("Kit nummer --> ");

            var userInput5 = 0;
            int.TryParse(Console.ReadLine(), out userInput5);
            //validate. cant be null
            //cant be null. validate
            //var kitToRemove = context.kitNeverExpires.Find(userInput5);
            bool wasSaved = false;
            if (category != 1 && category != 2)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Ukyldig kategorig tastet ind");
                Thread.Sleep(1000);
                Console.ForegroundColor = ConsoleColor.White;
            }
            if(category == 1)
            {
                await foreach (var kit in kitsDontExpire)  // get from db 
                {
                    if (kit.Id == userInput5)
                    {
                        context.kitNeverExpires.Remove(kit);
                        wasSaved = true;
                    }
                }
                if (!wasSaved)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($" ERR! - Kunne ikke finde et kit med id {userInput5}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Thread.Sleep(1000);
                }
                wasSaved = false;

            }
            if(category == 2)
            {
                await foreach (var kit in bpKits)   // get from async db service 
                {
                    if (kit.Id == userInput5)
                    {
                        context.BpKits.Remove(kit);
                        wasSaved = true;
                    }
                }
                if (!wasSaved)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($" ERR! - Kunne ikke finde et kit med id {userInput5}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Thread.Sleep(1000);
                }
                wasSaved = false;
            }
            
           
            await context.SaveChangesAsync().ConfigureAwait(false);

            Console.Clear();
            goto displayKitsMenu;
        }

        //tag kit 
        if (userinput2 == 4)
        {
        retry:;
            Console.WriteLine("\n");
            Console.WriteLine("(1)-- Kits --");
            await foreach (var kit in kitsDontExpire)
            {
                Console.WriteLine(kit.Id + ". " + kit.Name);
            }
            Console.WriteLine("\n");
            Console.WriteLine("(2)-- Bp Heads --");
            await foreach (var kit in bpKits)
            {
                Console.WriteLine(kit.Id + ". " + kit.Name);
            }


            Console.WriteLine("\n");
            Console.WriteLine("Hvilken kategorig vil du tage fra? kits: 1 / Bp kits: 2");
            Console.Write("--> ");
            var category = 0;
            int.TryParse(Console.ReadLine(), out category);
            if(category != 1 && category != 2)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Invalid kategorig indtasted: {category}");
                Console.ForegroundColor = ConsoleColor.White;
                Thread.Sleep(1000);
                Console.Clear();   
                goto displayKitsMenu;
            }
        Repeat:;
            Console.WriteLine("d. Done");
            Console.Write("Kit nummer --> ");
            var userInput6 = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(userInput6)) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("ERROR. Invalid ID. Try again."); Console.ForegroundColor = ConsoleColor.White; goto Repeat; }
            if(userInput6 == "d") { Console.Clear(); goto displayKitsMenu; } // DONE  
            else 
            {
                var userInputToInt = Convert.ToInt32(userInput6);
                bool wasSaved = false;

                if (category == 1)
                {
                    await foreach (var kit in kitsDontExpire)
                    {
                        if (kit.Id == userInputToInt)
                        {
                            await asyncDbTasks.SaveNEKitAsync(kit).ConfigureAwait(false);   // not correctly saving 
                            wasSaved = true;
                        }
                    }


                    if (!wasSaved)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($" ERR! - Kunne ikke finde et kit med id {userInput6}");
                        Console.ForegroundColor = ConsoleColor.White;
                        Thread.Sleep(1000);
                    }
                    wasSaved = false;
                }
                if (category == 2)
                {

                    await foreach (var kit in bpKits)
                    {
                        if (kit.Id == userInputToInt)
                        {
                            await asyncDbTasks.SaveBpKitAsync(kit).ConfigureAwait(false);
                            wasSaved = true;
                        }
                    }

                    if (!wasSaved)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($" ERR! - Kunne ikke finde et kit med id {userInput6}");
                        Console.ForegroundColor = ConsoleColor.White;
                        Thread.Sleep(1000);
                    }
                    wasSaved = false;
                }

                goto Repeat;
            }

       
        }
        //if (userinput2 == 5)
        //{
        //    Console.Write("Hvilket kit skal ændres?(Id) --> ");
        //    var kitId = 999999;
        //    int.TryParse(Console.ReadLine(), out kitId);
        //    /// validate 
        //    Console.Write("Hvor mange dage er der tilbage --> ");
        //    var daysLeft = 0;
        //    int.TryParse(Console.ReadLine(),out daysLeft);  

        //    await asyncDbTasks.set
        //}


    }
}
// Use no tacking   



async Task ThrowErrorAsyncInline(string message)
{
    //if(Console.ForegroundColor == ConsoleColor.Green)
    //{
    //    Console.ForegroundColor = ConsoleColor.Red;
    //    Console.WriteLine(message);
    //    Console.ForegroundColor = ConsoleColor.White;
    //    Console.ForegroundColor = ConsoleColor.Green;
    //}
    //else
    //{
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(message);
        Console.ForegroundColor = ConsoleColor.White;
    //}
  
}

 