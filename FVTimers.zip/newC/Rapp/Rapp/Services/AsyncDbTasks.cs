﻿using Microsoft.EntityFrameworkCore;
using Rapp.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rapp.Services
{

    public static class CompiledQueries
    {
        public static readonly Func<DbService, IAsyncEnumerable<Grund>>  GetGrundeAsync =
            EF.CompileAsyncQuery((DbService context) =>
            context.Grunde.AsNoTracking());

        public static readonly Func<DbService, IAsyncEnumerable<Invistering>> GetInvisteringerAsync = 
            EF.CompileAsyncQuery((DbService context) => 
            context.Invisteringer.AsNoTracking());

        public static readonly Func<DbService, IAsyncEnumerable<BpKit>> GetBpKitsAsync =
          EF.CompileAsyncQuery((DbService context) =>
          context.BpKits.AsNoTracking());
     
        public static readonly Func<DbService, string, Task<Grund>> GetSingleGrundAsync =
            EF.CompileAsyncQuery((DbService context, string grundName) =>
                context.Grunde.AsNoTracking().FirstOrDefault(g=>g.Name == grundName)
                    );
        // ALSO MIGHT NEED TO BE AS TRAKCKING AS IM UPDATING THE DATETIME PRPERTY ON THE ENTERTY AFTER RETRIVED 

        public static readonly Func<DbService, string, Task<Invistering>> GetSingleInvesteringAsync =
         EF.CompileAsyncQuery((DbService context, string investeringName) =>
             context.Invisteringer.AsNoTracking().FirstOrDefault(i => i.Name == investeringName)
                 );
        // ALSO MIGHT NEED AS TRACKING 

    }
    
    public class AsyncDbTasks
    {
        public async IAsyncEnumerable<Grund> GetGrundeAsync()
        {
            using (var context = new DbService())
            {
                //var grunde = await CompiledQueries.GetGrundeAsync(context).AsAsyncEnumerable().ConfigureAwait(false);
                await foreach(var item in CompiledQueries.GetGrundeAsync(context)) 
                {
                    yield return item;
                }
            }
        }

        public async IAsyncEnumerable<Invistering> GetInvisteringerAsync()
        {
            using (var context = new DbService())
            {
                await foreach(var item in CompiledQueries.GetInvisteringerAsync(context))
                {
                    yield return item;
                }
            }
        }

        public async IAsyncEnumerable<BpKit> GetBpKitsAsync()
        {
            using (var context = new DbService())
            {
                await foreach (var item in CompiledQueries.GetBpKitsAsync(context))
                {
                    yield return item;
                }
            }
        }

        public async Task<Grund> GetSingleGrundAsync(string grundNavn)
        {
            using (var context = new DbService())
            {
                return await CompiledQueries.GetSingleGrundAsync(context, grundNavn);
            }
        }

        public async Task<Invistering> GetSingleInvesteringAsync(string investeringName)
        {
            using(var context = new DbService())
            {
                return await CompiledQueries.GetSingleInvesteringAsync(context, investeringName);
            }
        }
        //using (var context = new DbService()
        //{
        //       var grunde = await CompiledQueries.GetGrundeAsync(contex);
        //});
        //public async IAsyncEnumerable<Grund> GetGrundeAsync()
        //{
        //    using (var context = new DbService())
        //    {
        //        var grunde = context.Grunde.AsAsyncEnumerable();
        //        await foreach (var item in grunde)
        //        {
        //            yield return item;
        //        }

        //    }
        //}
    }
}
