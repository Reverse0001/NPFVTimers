﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rapp.Models
{
    public class Grund
    {
        public int Id { get; set; }
        public string Name { get; set; }
      //  public int DaysLeft { get; set; }
        public DateTime LastTimeDaysWereAddedDate { get; set; }
        //public TimeSpan LastTimeDaysWereAddedTime { get; set; }
        //public DateTime ExpireDateDate { get; set; }
        //public TimeSpan ExpireDateTime { get; set; }
    }
}
