﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Rapp.Models;
using Rapp.Services;
using System.Diagnostics;

var userInput = 0;
var asyncDbTasks = new AsyncDbTasks();
var grunde = asyncDbTasks.GetGrundeAsync();
while (true)
{
    Console.WriteLine("FV Dashboard");
    Console.WriteLine("\n");
    Console.WriteLine("--- Options ---");
    Console.WriteLine("1. Grunde.");
    Console.WriteLine("2. Investeringer.");
    Console.WriteLine("3. BP Kits.");
    Console.WriteLine("4. Buy/Rank Kits. // Ikke lavet endnu");
    Console.Write("--> ");
    int.TryParse(Console.ReadLine(), out userInput);
    if (userInput != 1 && userInput != 2 && userInput != 3)
    {
        Console.Clear();
    }
    else if (userInput == 1)            // Logic to prevent a user from creaitng multiple of type<Any> Model with same name
    {


        // ehite space / empty 
        // findes allerade? 
        // 

        Console.Clear();
        grundeLabel:; 
        using (var context = new DbService())
        {
            Console.WriteLine("     --- Dine Grunde ---");
            await foreach (var grund in grunde)
            {
                var dagee2 = grund.LastTimeDaysWereAddedDate + TimeSpan.FromDays(9);
                var tilbage = (dagee2 - DateTime.Now).TotalDays;
                Console.WriteLine("---------------------------------");
                Console.WriteLine($"Navn: {grund.Name}."); 
                Console.WriteLine($"Udløber den: {dagee2}(Tidligst)");
                Console.WriteLine($"Udløber om: {tilbage}, dage(Tidligst)");
                if (tilbage <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart. Add dage."); }
                if (tilbage <= 6) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Alt er fint"); }
                if (tilbage <= 10) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer"); }
                Console.ForegroundColor = ConsoleColor.White;
            }
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("--- Options ---");
            Console.WriteLine("1. Add Grund");
            Console.WriteLine("2. Del Grund");
            Console.WriteLine("3. AddDays Grund");
            Console.WriteLine("X/Enter. Go back");
            Console.Write("--> ");
            var userInput2 = 0;
         
            int.TryParse(Console.ReadLine(), out userInput2);
            if (userInput2 != 1 && userInput2 != 2 && userInput2 != 3)
            {
                Console.Clear();
            }

            if (userInput2 == 1)
            {
            tryagain:;
                Console.WriteLine("Fortryd?: f");
                Console.Write("Grund Navn --> ");
                var grundNavn = Console.ReadLine();
                if(grundNavn == "f") { Console.Clear(); goto grundeLabel; }  else
                {
                    if(String.IsNullOrWhiteSpace(grundNavn)) { Console.WriteLine("Din grund skal have et navn"); goto tryagain; }
                    await foreach(var grund in grunde)
                    {
                        if(grund.Name == grundNavn) { Console.WriteLine("Dine grunde skal have unikke navne"); goto tryagain; }
                    }
                    var grundSomAddes = new Grund()
                    {
                        Name = grundNavn,
                        LastTimeDaysWereAddedDate = DateTime.Now,

                    };
                    context.Grunde.Add(grundSomAddes);
                    context.SaveChanges();
                    Console.Clear();
                    goto grundeLabel;
                }
            }
            if(userInput2 == 2)
            {
            delgrundretry:;
                bool wasDeleted = false;
                Console.WriteLine("Fortryd?: f");
                Console.Write("Slet grund med navnet --> ");
                var grundToDelete = Console.ReadLine();
                if (grundToDelete == "f") { Console.Clear(); goto grundeLabel; }
                else
                {
                    if(String.IsNullOrWhiteSpace(grundToDelete)) { Console.WriteLine("Invalid grund navn"); goto delgrundretry; }
                    await foreach (var grund in grunde)
                    {
                        if (grund.Name == grundToDelete)
                        {
                            context.Remove(grund);
                            wasDeleted = true;
                        }
                    }
                    context.SaveChanges();
                    if (wasDeleted == false) { Console.WriteLine($"Kunne ikke finde en grund med navnet {grundToDelete}. Tryk enter for at gå tilbage"); goto delgrundretry; }
                    Console.Clear();
                    goto grundeLabel;

                }
              
            }
            if (userInput2 == 3)
            {
            retryyy:;
                Console.WriteLine("Fortryd?: f");
                Console.Write("Hvilken grund(navn)? --> ");
                var grundNavn = Console.ReadLine();
                if(grundNavn == "f")
                {
                    Console.Clear();
                    goto grundeLabel;
                }
                else
                {
                    if(String.IsNullOrWhiteSpace(grundNavn)) { Console.WriteLine("Invalid grund navn"); goto retryyy; }
                    var grundDerSkalOpdateres = context.Grunde.FirstOrDefault(g => g.Name == grundNavn);
                    if(grundDerSkalOpdateres == null) { Console.WriteLine($"Kunne ikke finde en grund med navnet {grundNavn}. Tryk enter for at gå tilbage"); goto retryyy;  }
                    Console.WriteLine("1. Add max dage");
                    Console.WriteLine("2. Set specifik tid // Ikke lavet endnu");
                    Console.WriteLine("9. Fortryd");
                retry:;
                    Console.Write("--> ");
                    var userInput3 = 0;
                    int.TryParse(Console.ReadLine(), out userInput3);
                   
                    if(userInput3 != 1  && userInput3 != 2 && userInput3 != 9)
                    {
                        Console.WriteLine("Invalid input");
                        goto retry;
                    }
                    if(userInput3 == 9)
                    {
                        Console.Clear();
                        goto grundeLabel;
                    }
                    if(userInput3 == 1)
                    {
                        // add 9 dage 
                        grundDerSkalOpdateres.LastTimeDaysWereAddedDate = DateTime.Now;
                    }
                    else if (userInput3 == 2)
                    {
                        // Specifik dage set 
                        // ikke lavet endnu
                    }
                    context.SaveChanges();
                    Console.Clear();
                    goto grundeLabel;
                }
            }
        }
    }
    else if (userInput == 2)
    {
        Console.Clear();
        using(var context = new DbService())  
        {                      // hvis noget som helst er klart til at blive taget. skal der laves om paa hvad der bliver vist og farverne skla laves om 
        invisteringer:;
            Console.WriteLine("  --- Dine Invisteringer ---");
            var invisteringer = asyncDbTasks.GetInvisteringerAsync();
                //context.Invisteringer.ToList(); 
            await foreach (var invist in invisteringer)
            {
                DateTime Udlllob = invist.LastTakenDate.AddDays(10);
                DateTime targetTime = invist.LastTakenDate.AddHours(24);
                TimeSpan kanTagesOm = targetTime - DateTime.Now;
                var udlooberOm=(Udlllob - DateTime.Now).TotalDays;
                if(targetTime < DateTime.Now)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("---------------------------------");
                    Console.WriteLine($"Invisterings navn: {invist.Name}");
                    Console.WriteLine($"Denne invistering er klar!:D");
                    //Console.WriteLine($"Kan tages om: {kanTagesOm}, Timer/Min/Sek");
                    Console.WriteLine($"Udløber om: {udlooberOm}, Dage");
                    Console.WriteLine($"Udløber den: {invist.LastTakenDate}");
                    if (udlooberOm <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart"); }
                    if (udlooberOm <= 6) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Alt er fint"); }
                    if (udlooberOm <= 10) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer"); }
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {

                    Console.WriteLine("---------------------------------");
                    Console.WriteLine($"Invisterings navn: {invist.Name}");
                    Console.WriteLine($"Kan tages om: {kanTagesOm}, Timer/Min/Sek");
                    Console.WriteLine($"Udløber om: {udlooberOm}, Dage");
                    Console.WriteLine($"Udløber den: {invist.LastTakenDate}");
                    if (udlooberOm <= 3) { Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("State: Critical. Udløber snart"); }
                    if (udlooberOm <= 6) { Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("State: Alright. Alt er fint"); }
                    if (udlooberOm <= 10) { Console.ForegroundColor = ConsoleColor.Green; Console.WriteLine("State: Godt. Ingen farer"); }
                    Console.ForegroundColor = ConsoleColor.White;
                }

            }
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("--- Options ---");
            Console.WriteLine("1. Opret Invistering");
            Console.WriteLine("2. Slet Invisterings");
            Console.WriteLine("3. Rest timer");
            Console.WriteLine("x/Enter. Gå tilbage");
            Console.Write("--> ");
            var userInput5 = 0;
            int.TryParse(Console.ReadLine(), out userInput5);
            if(userInput5 != 1 && userInput5 != 2 && userInput5 != 3)
            {
                // Invalid   NVM  er bare et tilbage call x/Enter
            }
            if(userInput5 == 1)
            {
            invisretry:;
                Console.WriteLine("f. Fortryd");
                Console.Write("Invisterings navn? --> ");
                var invisteringNavn = Console.ReadLine();
                //VAlidate inpt  // unikt navn 
                if(invisteringNavn == "f") { Console.Clear(); goto invisteringer; }
                if(String.IsNullOrWhiteSpace(invisteringNavn)) { Console.WriteLine("Invalid invisterings navn"); goto invisretry;  }
                await foreach (var inv in invisteringer) { if (inv.Name == invisteringNavn) { Console.WriteLine("Dine invisteringer skal have unikke navne"); goto invisretry; } }
                var newInvistering = new Invistering { LastTakenDate = DateTime.Now, Name = invisteringNavn };
                context.Invisteringer.Add(newInvistering);
                context.SaveChanges();
                Console.Clear() ;
                goto invisteringer;
            }
            if(userInput5 == 2)
            {
            retry:;
                Console.WriteLine("f. Fortryd");
                Console.Write("Hvilken invistering skal slettes?(Navn) --> ");
                var invisteringToDel = Console.ReadLine(); // validate
                if (invisteringToDel == "f") { Console.Clear(); goto invisteringer; }
                if (String.IsNullOrWhiteSpace(invisteringToDel)) { Console.WriteLine("Invalid invisterings navn"); goto retry; }
                var invisteringList = context.Invisteringer.FirstOrDefault(i=>i.Name == invisteringToDel);
                if(invisteringList == null) { Console.WriteLine($"Kunne ikke finde en invistering med navnet {invisteringToDel}"); goto retry; }
                context.Invisteringer.Remove(invisteringList);
                context.SaveChanges();
                Console.Clear();
                goto invisteringer;
            }
            if(userInput5 == 3)
            {
            retry3:;
                Console.WriteLine("f. Fortryd");
                Console.Write("Hvilken invistering skal resettes?(Navn) --> ");
                var invisteringToReset = Console.ReadLine(); // validate

                if (invisteringToReset == "f") { Console.Clear(); goto invisteringer; }
                if (String.IsNullOrWhiteSpace(invisteringToReset)) { Console.WriteLine("Invalid invisterings navn"); goto retry3; }
                var invisteringFromDb = context.Invisteringer.FirstOrDefault(i => i.Name == invisteringToReset);
                if (invisteringFromDb == null) { Console.WriteLine($"Kunne ikke finde en Invistering med navnet {invisteringToReset}"); goto retry3; }
                invisteringFromDb.LastTakenDate = DateTime.Now;
                context.SaveChanges();
                Console.Clear();
                goto invisteringer;
            }
            Console.Clear();
        }
        //Invisteringer 
    }
    else if (userInput == 3)
    {
        Console.Clear();
        kitlabel:;
        using (var context = new DbService())
        {
            var kits = context.kits.ToList();
            Console.WriteLine("      --- Dine BP kits ---");
            foreach (var kit in kits)
            {
                DateTime udlooberOm = kit.LastTaken.AddDays(7);
                DateTime targetTime = kit.LastTaken.AddHours(24);
                TimeSpan kanTagesOm = targetTime - DateTime.Now;
                var udlooberrOm =(udlooberOm - DateTime.Now).TotalDays;
             
                    Console.WriteLine("---------------------------------");
                    Console.WriteLine($"Kit: {kit.Name}");
                    Console.WriteLine($"Kan tages om {kanTagesOm}, Timer/Min/sek");
                    Console.WriteLine($"Kit udløber om {udlooberrOm}, Dage"); // cal
                    Console.WriteLine($"Udløber den: {kit.ExpireDate}");
             
                
            }
            Console.WriteLine("---------------------------------");
            Console.WriteLine("\n");
            Console.WriteLine("--- Options ---");
            Console.WriteLine("1. Opret kit");
            Console.WriteLine("2. Fjern kit");
            Console.WriteLine("3. Reset kit Timer");
            Console.WriteLine("x/Enter. Gå tilbage");
            Console.Write("--> ");
            var userInput4 = 0;
            int.TryParse(Console.ReadLine(), out userInput4);
            if(userInput4 != 1 && userInput4 != 2 && userInput4 != 3) 
            {
                // invalid input
            }
            if(userInput4 == 1)
            { 
                Console.WriteLine("f. Fortryd");
                Console.Write("Kit navn? --> ");
                var kitNavn = Console.ReadLine();
                if(kitNavn == "f")
                {
                    Console.Clear();
                    goto kitlabel;
                }
                else {

                            //TODO ADD kit name value validation 
                    var newKit = new Kit { Name = kitNavn, LastTaken = DateTime.Now, ExpireDate = DateTime.Now + TimeSpan.FromDays(7) };
                    context.kits.Add(newKit);
                    context.SaveChanges();
                    Console.Clear();
                    goto kitlabel;

                }

            }
            if(userInput4 == 2)
            {
                Console.Write("Hvilket kit skal Fjernes?(Navn) --> ");
                var kitSomSkalFjernes = Console.ReadLine();
                foreach(var kit in context.kits)
                {
                    if(kit.Name == kitSomSkalFjernes)
                    {
                        context.Remove(kit);
                    }
                }
                context.SaveChanges();
                Console.Clear();
                goto kitlabel;
            }
            if(userInput4 == 3)
            {
                Console.Write("Hvilket kit skal resettes?(Navn) --> ");
                var kitSomSkalResettes = Console.ReadLine();
                foreach(var kit in context.kits)
                {
                    if(kit.Name == kitSomSkalResettes)
                    {
                        kit.LastTaken = DateTime.Now;
                    }
                }
                context.SaveChanges() ;
                Console.Clear();
                goto kitlabel;
            }
            Console.Clear();
            

        }
         
        // Kits 
    }
    else if(userInput == 4)
    {
        // BÙY / Rank KIts 
    }
}




 