﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rapp.Migrations
{
    /// <inheritdoc />
    public partial class new2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ExpireDateDate",
                table: "Invisteringer");

            migrationBuilder.DropColumn(
                name: "ExpireDateTime",
                table: "Invisteringer");

            migrationBuilder.DropColumn(
                name: "LastTakenTime",
                table: "Invisteringer");

            migrationBuilder.DropColumn(
                name: "ExpireDateDate",
                table: "Grunde");

            migrationBuilder.DropColumn(
                name: "ExpireDateTime",
                table: "Grunde");

            migrationBuilder.DropColumn(
                name: "LastTimeDaysWereAddedTime",
                table: "Grunde");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "ExpireDateDate",
                table: "Invisteringer",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<TimeSpan>(
                name: "ExpireDateTime",
                table: "Invisteringer",
                type: "time",
                nullable: false,
                defaultValue: new TimeSpan(0, 0, 0, 0, 0));

            migrationBuilder.AddColumn<TimeSpan>(
                name: "LastTakenTime",
                table: "Invisteringer",
                type: "time",
                nullable: false,
                defaultValue: new TimeSpan(0, 0, 0, 0, 0));

            migrationBuilder.AddColumn<DateTime>(
                name: "ExpireDateDate",
                table: "Grunde",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<TimeSpan>(
                name: "ExpireDateTime",
                table: "Grunde",
                type: "time",
                nullable: false,
                defaultValue: new TimeSpan(0, 0, 0, 0, 0));

            migrationBuilder.AddColumn<TimeSpan>(
                name: "LastTimeDaysWereAddedTime",
                table: "Grunde",
                type: "time",
                nullable: false,
                defaultValue: new TimeSpan(0, 0, 0, 0, 0));
        }
    }
}
