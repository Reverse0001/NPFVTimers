﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rapp.Migrations
{
    /// <inheritdoc />
    public partial class new4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ExpiresIn",
                table: "Invisteringer");

            migrationBuilder.DropColumn(
                name: "DaysLeft",
                table: "Grunde");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ExpiresIn",
                table: "Invisteringer",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "DaysLeft",
                table: "Grunde",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
