﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rapp.Migrations
{
    /// <inheritdoc />
    public partial class @new : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Grunde",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DaysLeft = table.Column<int>(type: "int", nullable: false),
                    LastTimeDaysWereAddedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastTimeDaysWereAddedTime = table.Column<TimeSpan>(type: "time", nullable: false),
                    ExpireDateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExpireDateTime = table.Column<TimeSpan>(type: "time", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Grunde", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Invisteringer",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ExpiresIn = table.Column<int>(type: "int", nullable: false),
                    ExpireDateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExpireDateTime = table.Column<TimeSpan>(type: "time", nullable: false),
                    LastTakenDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastTakenTime = table.Column<TimeSpan>(type: "time", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Invisteringer", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Grunde");

            migrationBuilder.DropTable(
                name: "Invisteringer");
        }
    }
}
