﻿using Microsoft.EntityFrameworkCore;
using Rapp.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rapp.Services
{

    public static class CompiledQueries
    {
        public static readonly Func<DbService, IAsyncEnumerable<Grund>>  GetGrundeAsync =
            EF.CompileAsyncQuery((DbService context) =>
            context.Grunde.AsNoTracking());

        public static readonly Func<DbService, IAsyncEnumerable<Invistering>> GetInvisteringerAsync = 
            EF.CompileAsyncQuery((DbService context) => 
            context.Invisteringer.AsNoTracking());
    }
    
    public class AsyncDbTasks
    {
        public async IAsyncEnumerable<Grund> GetGrundeAsync()
        {
            using (var context = new DbService())
            {
                //var grunde = await CompiledQueries.GetGrundeAsync(context).AsAsyncEnumerable().ConfigureAwait(false);
                await foreach(var item in CompiledQueries.GetGrundeAsync(context)) 
                {
                    yield return item;
                }
            }
        }

        public async IAsyncEnumerable<Invistering> GetInvisteringerAsync()
        {
            using (var context = new DbService())
            {
                await foreach(var item in CompiledQueries.GetInvisteringerAsync(context))
                {
                    yield return item;
                }
            }
        }



        //using (var context = new DbService()
        //{
        //       var grunde = await CompiledQueries.GetGrundeAsync(contex);
        //});
        //public async IAsyncEnumerable<Grund> GetGrundeAsync()
        //{
        //    using (var context = new DbService())
        //    {
        //        var grunde = context.Grunde.AsAsyncEnumerable();
        //        await foreach (var item in grunde)
        //        {
        //            yield return item;
        //        }

        //    }
        //}
    }
}
