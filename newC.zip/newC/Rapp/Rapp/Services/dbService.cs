﻿using Microsoft.EntityFrameworkCore;
using Rapp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rapp.Services
{
    public class DbService : DbContext
    {
        public DbSet<Grund> Grunde { get; set; }
        public DbSet<Invistering> Invisteringer { get; set; }
        public DbSet<Kit> kits { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=MyFVDV;Trusted_Connection=True;");
        }
    }
}
